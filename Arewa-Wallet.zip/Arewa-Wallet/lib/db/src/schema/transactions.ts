import {
  pgTable,
  serial,
  integer,
  varchar,
  numeric,
  timestamp,
} from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";
import { usersTable } from "./users";

export const transactionsTable = pgTable("transactions", {
  id: serial("id").primaryKey(),
  userId: integer("user_id")
    .notNull()
    .references(() => usersTable.id),
  /** send | receive | airtime | bill | deposit */
  type: varchar("type", { length: 20 }).notNull(),
  /** Positive = credit, negative = debit */
  amount: numeric("amount", { precision: 15, scale: 2 }).notNull(),
  /** Human-readable name: recipient, sender, or provider */
  counterparty: varchar("counterparty", { length: 255 }).notNull(),
  /** Optional account/phone for airtime & bills */
  counterpartyAccount: varchar("counterparty_account", { length: 50 }),
  reference: varchar("reference", { length: 50 }).notNull().unique(),
  status: varchar("status", { length: 20 }).notNull().default("completed"),
  createdAt: timestamp("created_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
});

export const insertTransactionSchema = createInsertSchema(
  transactionsTable,
).omit({ id: true, createdAt: true });
export type InsertTransaction = z.infer<typeof insertTransactionSchema>;
export type DbTransaction = typeof transactionsTable.$inferSelect;
