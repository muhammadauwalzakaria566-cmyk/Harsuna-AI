const API_BASE = "/api";

async function request<T>(
  path: string,
  options?: RequestInit,
): Promise<T> {
  const res = await fetch(`${API_BASE}${path}`, {
    headers: { "Content-Type": "application/json" },
    credentials: "include",
    ...options,
  });
  const data = await res.json();
  if (!res.ok) {
    throw new Error(
      (data as { error?: string }).error ?? "Kuskure / Request failed",
    );
  }
  return data as T;
}

export const api = {
  get: <T>(path: string) => request<T>(path),
  post: <T>(path: string, body: unknown) =>
    request<T>(path, {
      method: "POST",
      body: JSON.stringify(body),
    }),
};

// ── Typed shapes returned by the API ─────────────────────────────────────────

export interface AuthUser {
  id: number;
  phone: string;
  fullName: string;
  accountNumber: string;
  balance: string;
}

export interface ApiTransaction {
  id: number;
  userId: number;
  type: "send" | "receive" | "airtime" | "bill" | "deposit";
  amount: string;          // numeric string, positive = credit, negative = debit
  counterparty: string;
  counterpartyAccount: string | null;
  reference: string;
  status: string;
  createdAt: string;       // ISO timestamp
}
