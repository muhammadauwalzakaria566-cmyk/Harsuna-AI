import { PageTransition } from "@/components/PageTransition";
import { DbTransactionRow } from "@/components/DbTransactionRow";
import { cn } from "@/lib/utils";
import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { api, type ApiTransaction } from "@/lib/api";
import { Skeleton } from "@/components/ui/skeleton";
import { Receipt } from "lucide-react";

const MONTHS = [
  { id: "all", label: "Duka / All" },
  { id: "jul", label: "Yuli / July" },
  { id: "jun", label: "Yun / June" },
  { id: "may", label: "Mayu / May" },
];

function txMonth(isoStr: string): string {
  return new Date(isoStr).toLocaleString("en-US", { month: "short" }).toLowerCase();
}

function groupByDate(txns: ApiTransaction[]): Record<string, ApiTransaction[]> {
  const groups: Record<string, ApiTransaction[]> = {};
  const now = new Date();
  for (const t of txns) {
    const d = new Date(t.createdAt);
    const diffDays = Math.floor((now.getTime() - d.getTime()) / 86_400_000);
    let key: string;
    if (diffDays === 0) key = "Yau / Today";
    else if (diffDays === 1) key = "Jiya / Yesterday";
    else key = d.toLocaleDateString("en-NG", { day: "numeric", month: "long", year: "numeric" });
    (groups[key] ??= []).push(t);
  }
  return groups;
}

export default function History() {
  const [activeMonth, setActiveMonth] = useState("all");

  const { data: allTransactions = [], isLoading } = useQuery<ApiTransaction[]>({
    queryKey: ["transactions"],
    queryFn: () => api.get<ApiTransaction[]>("/transactions"),
    staleTime: 30_000,
  });

  const filtered =
    activeMonth === "all"
      ? allTransactions
      : allTransactions.filter((t) => txMonth(t.createdAt) === activeMonth);

  const grouped = groupByDate(filtered);

  const totalIn = filtered
    .filter((t) => parseFloat(t.amount) > 0)
    .reduce((s, t) => s + parseFloat(t.amount), 0);

  const totalOut = filtered
    .filter((t) => parseFloat(t.amount) < 0)
    .reduce((s, t) => s + Math.abs(parseFloat(t.amount)), 0);

  return (
    <PageTransition className="flex flex-col min-h-screen bg-background">
      <header className="px-5 pt-8 pb-4 sticky top-0 bg-background/80 backdrop-blur-md z-10 border-b border-border/50">
        <h1 className="text-xl font-bold text-foreground leading-tight">Tarihin Ciniki</h1>
        <p className="text-sm text-muted-foreground font-medium">Transaction History</p>
      </header>

      <main className="flex-1">
        {/* Month filter */}
        <div className="px-5 py-4 overflow-x-auto hide-scrollbar flex gap-2">
          {MONTHS.map((month) => (
            <button
              key={month.id}
              onClick={() => setActiveMonth(month.id)}
              className={cn(
                "px-4 py-2 rounded-full text-sm font-semibold transition-colors whitespace-nowrap outline-none",
                activeMonth === month.id
                  ? "bg-foreground text-background"
                  : "bg-card border border-border text-foreground hover:bg-muted",
              )}
            >
              {month.label}
            </button>
          ))}
        </div>

        {/* Summary card */}
        <div className="px-5 mb-6">
          <div className="bg-card border border-border rounded-2xl p-4 flex shadow-sm">
            <div className="flex-1 flex flex-col justify-center border-r border-border px-2">
              <span className="text-xs text-muted-foreground mb-1">Shiga / In</span>
              <span className="font-bold text-primary">
                ₦{totalIn.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
              </span>
            </div>
            <div className="flex-1 flex flex-col justify-center px-4">
              <span className="text-xs text-muted-foreground mb-1">Fita / Out</span>
              <span className="font-bold text-destructive">
                ₦{totalOut.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
              </span>
            </div>
          </div>
        </div>

        {/* Transaction list */}
        {isLoading ? (
          <div className="px-5 flex flex-col gap-4">
            {[1, 2, 3, 4].map((i) => (
              <div key={i} className="flex items-center gap-3 py-1">
                <Skeleton className="w-11 h-11 rounded-full" />
                <div className="flex-1 space-y-1.5">
                  <Skeleton className="h-3.5 w-32 rounded" />
                  <Skeleton className="h-3 w-24 rounded" />
                </div>
                <Skeleton className="h-3.5 w-16 rounded" />
              </div>
            ))}
          </div>
        ) : filtered.length === 0 ? (
          <div className="flex flex-col items-center justify-center px-5 py-16 text-center gap-4">
            <div className="w-16 h-16 rounded-3xl bg-muted flex items-center justify-center">
              <Receipt className="w-7 h-7 text-muted-foreground/50" />
            </div>
            <div>
              <p className="font-bold text-foreground">Babu Ciniki</p>
              <p className="text-sm text-muted-foreground mt-1">No transactions yet</p>
            </div>
          </div>
        ) : (
          <div className="px-5 flex flex-col gap-6 pb-4">
            {Object.entries(grouped).map(([dateLabel, txns]) => (
              <div key={dateLabel}>
                <h3 className="text-xs font-semibold text-muted-foreground mb-3 uppercase tracking-wider">
                  {dateLabel}
                </h3>
                <div className="bg-card border border-border rounded-2xl p-4 shadow-sm flex flex-col divide-y divide-border/50">
                  {txns.map((t) => (
                    <DbTransactionRow key={t.id} txn={t} />
                  ))}
                </div>
              </div>
            ))}
          </div>
        )}
      </main>
    </PageTransition>
  );
}
