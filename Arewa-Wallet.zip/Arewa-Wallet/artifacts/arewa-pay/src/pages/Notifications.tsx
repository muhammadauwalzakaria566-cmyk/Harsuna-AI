import { ArrowLeft, ArrowDownToLine, Phone, Zap, ArrowUpFromLine, ShieldCheck, Bell } from "lucide-react";
import { Link } from "wouter";
import { useState } from "react";
import { cn } from "@/lib/utils";
import { PageTransition } from "@/components/PageTransition";

type NotifType = "received" | "sent" | "airtime" | "bill" | "security" | "promo";

interface Notification {
  id: string;
  type: NotifType;
  titleHa: string;
  titleEn: string;
  bodyHa: string;
  bodyEn: string;
  amount?: string;
  time: string;
  read: boolean;
}

const MOCK_NOTIFICATIONS: Notification[] = [
  {
    id: "n1",
    type: "received",
    titleHa: "An Karɓi Kuɗi",
    titleEn: "Money Received",
    bodyHa: "Musa Sule ya aika maka ₦15,000.00",
    bodyEn: "Musa Sule sent you ₦15,000.00",
    amount: "+₦15,000",
    time: "Yau, 9:42 AM",
    read: false,
  },
  {
    id: "n2",
    type: "airtime",
    titleHa: "An Siya Katin Waya",
    titleEn: "Airtime Purchased",
    bodyHa: "An siya MTN airtime ₦1,000 zuwa 080 1234 5678",
    bodyEn: "MTN airtime of ₦1,000 sent to 080 1234 5678",
    amount: "-₦1,000",
    time: "Yau, 7:15 AM",
    read: false,
  },
  {
    id: "n3",
    type: "bill",
    titleHa: "Lissafin Wutar Lantarki",
    titleEn: "Electricity Bill Paid",
    bodyHa: "An biya AEDC ₦8,500.00 da nasara",
    bodyEn: "AEDC payment of ₦8,500.00 was successful",
    amount: "-₦8,500",
    time: "Jiya, 6:30 PM",
    read: false,
  },
  {
    id: "n4",
    type: "sent",
    titleHa: "An Aika Kuɗi",
    titleEn: "Money Sent",
    bodyHa: "An aika ₦5,000.00 zuwa Aisha Musa",
    bodyEn: "You sent ₦5,000.00 to Aisha Musa",
    amount: "-₦5,000",
    time: "Jiya, 2:10 PM",
    read: true,
  },
  {
    id: "n5",
    type: "security",
    titleHa: "Shiga Sabon Na'ura",
    titleEn: "New Device Login",
    bodyHa: "An shiga asusunka daga sabon wayar hannu",
    bodyEn: "Your account was accessed from a new device",
    time: "Jiya, 10:55 AM",
    read: true,
  },
  {
    id: "n6",
    type: "received",
    titleHa: "An Karɓi Kuɗi",
    titleEn: "Money Received",
    bodyHa: "Fatima Bello ta aika maka ₦20,000.00",
    bodyEn: "Fatima Bello sent you ₦20,000.00",
    amount: "+₦20,000",
    time: "Kwana 2 da suka wuce / 2 days ago",
    read: true,
  },
  {
    id: "n7",
    type: "promo",
    titleHa: "Tayin Arewa Pay",
    titleEn: "Arewa Pay Offer",
    bodyHa: "Aika kuɗi yau ka sami cashback 1%!",
    bodyEn: "Send money today and earn 1% cashback!",
    time: "Kwana 3 da suka wuce / 3 days ago",
    read: true,
  },
];

const ICON_MAP: Record<NotifType, { icon: React.ElementType; bg: string; color: string }> = {
  received:  { icon: ArrowDownToLine, bg: "bg-[#E4E8F2]",  color: "text-[#2B3A67]" },
  sent:      { icon: ArrowUpFromLine, bg: "bg-orange-50",   color: "text-orange-500" },
  airtime:   { icon: Phone,           bg: "bg-primary/10",  color: "text-primary" },
  bill:      { icon: Zap,             bg: "bg-[#F3E4D9]",   color: "text-[#C97B4A]" },
  security:  { icon: ShieldCheck,     bg: "bg-red-50",      color: "text-red-500" },
  promo:     { icon: Bell,            bg: "bg-accent/15",   color: "text-accent-foreground" },
};

export default function Notifications() {
  const [notifications, setNotifications] = useState(MOCK_NOTIFICATIONS);

  const unreadCount = notifications.filter((n) => !n.read).length;

  const markAllRead = () =>
    setNotifications((prev) => prev.map((n) => ({ ...n, read: true })));

  const markOneRead = (id: string) =>
    setNotifications((prev) =>
      prev.map((n) => (n.id === id ? { ...n, read: true } : n))
    );

  const todayItems = notifications.filter((n) =>
    n.time.startsWith("Yau")
  );
  const yesterdayItems = notifications.filter((n) =>
    n.time.startsWith("Jiya")
  );
  const olderItems = notifications.filter(
    (n) => !n.time.startsWith("Yau") && !n.time.startsWith("Jiya")
  );

  return (
    <PageTransition className="flex flex-col min-h-screen bg-background">
      {/* Header */}
      <header className="px-5 pt-8 pb-4 flex items-center justify-between sticky top-0 bg-background/80 backdrop-blur-md z-10 border-b border-border/40">
        <div className="flex items-center gap-4">
          <Link
            href="/"
            className="w-10 h-10 rounded-full bg-card border border-border flex items-center justify-center shrink-0 active:scale-95 transition-transform"
          >
            <ArrowLeft className="w-5 h-5 text-foreground" />
          </Link>
          <div>
            <h1 className="text-lg font-bold text-foreground leading-tight">
              Sanarwa
            </h1>
            <p className="text-xs text-muted-foreground font-medium">
              Notifications
            </p>
          </div>
        </div>

        {unreadCount > 0 && (
          <button
            onClick={markAllRead}
            className="text-xs font-semibold text-primary active:opacity-70 transition-opacity px-1"
          >
            Karanta Duka{"\n"}
            <span className="text-muted-foreground font-normal">Mark all read</span>
          </button>
        )}
      </header>

      {/* Unread badge */}
      {unreadCount > 0 && (
        <div className="mx-5 mt-4 px-4 py-3 rounded-2xl bg-accent/15 border border-accent/30 flex items-center gap-3">
          <div className="w-8 h-8 rounded-full bg-accent/20 flex items-center justify-center shrink-0">
            <Bell className="w-4 h-4 text-accent-foreground" />
          </div>
          <p className="text-sm font-semibold text-foreground">
            {unreadCount === 1
              ? "Sanarwa 1 da ba a karanta ba / 1 unread notification"
              : `Sanarwa ${unreadCount} da ba a karanta ba / ${unreadCount} unread notifications`}
          </p>
        </div>
      )}

      <main className="flex-1 px-5 pt-4 pb-6 flex flex-col gap-1">
        {todayItems.length > 0 && (
          <Section label="Yau / Today" items={todayItems} onRead={markOneRead} />
        )}
        {yesterdayItems.length > 0 && (
          <Section label="Jiya / Yesterday" items={yesterdayItems} onRead={markOneRead} />
        )}
        {olderItems.length > 0 && (
          <Section label="Da Wuce / Earlier" items={olderItems} onRead={markOneRead} />
        )}
      </main>
    </PageTransition>
  );
}

function Section({
  label,
  items,
  onRead,
}: {
  label: string;
  items: Notification[];
  onRead: (id: string) => void;
}) {
  return (
    <section className="mb-2">
      <p className="text-[11px] font-semibold text-muted-foreground uppercase tracking-wider px-1 py-3">
        {label}
      </p>
      <div className="bg-card border border-border rounded-3xl overflow-hidden shadow-sm divide-y divide-border/50">
        {items.map((n) => (
          <NotifRow key={n.id} notif={n} onRead={onRead} />
        ))}
      </div>
    </section>
  );
}

function NotifRow({
  notif,
  onRead,
}: {
  notif: Notification;
  onRead: (id: string) => void;
}) {
  const { icon: Icon, bg, color } = ICON_MAP[notif.type];

  return (
    <button
      onClick={() => onRead(notif.id)}
      className={cn(
        "w-full flex items-start gap-4 px-4 py-4 text-left transition-colors active:bg-muted/50",
        !notif.read && "bg-primary/[0.03]"
      )}
    >
      {/* Icon */}
      <div className={cn("w-11 h-11 rounded-2xl flex items-center justify-center shrink-0 mt-0.5", bg)}>
        <Icon className={cn("w-5 h-5", color)} />
      </div>

      {/* Text */}
      <div className="flex-1 min-w-0">
        <div className="flex items-start justify-between gap-2">
          <div className="min-w-0">
            <p className={cn("text-sm leading-snug truncate", notif.read ? "font-medium text-foreground" : "font-bold text-foreground")}>
              {notif.titleHa}
            </p>
            <p className="text-[11px] text-muted-foreground font-normal leading-snug truncate">
              {notif.titleEn}
            </p>
          </div>
          {notif.amount && (
            <span
              className={cn(
                "text-sm font-bold shrink-0 tabular-nums",
                notif.amount.startsWith("+") ? "text-primary" : "text-foreground"
              )}
            >
              {notif.amount}
            </span>
          )}
        </div>
        <p className="text-xs text-muted-foreground mt-1.5 leading-snug line-clamp-2">
          {notif.bodyEn}
        </p>
        <p className="text-[10px] text-muted-foreground/70 mt-1 font-medium">
          {notif.time}
        </p>
      </div>

      {/* Unread dot */}
      {!notif.read && (
        <div className="w-2.5 h-2.5 rounded-full bg-accent shrink-0 mt-1.5" />
      )}
    </button>
  );
}
