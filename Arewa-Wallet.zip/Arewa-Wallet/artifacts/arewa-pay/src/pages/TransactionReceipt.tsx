import { ArrowLeft, CheckCircle2, Clock, XCircle, Copy, Share2 } from "lucide-react";
import { Link, useParams } from "wouter";
import { MOCK_TRANSACTIONS } from "@/components/TransactionItem";
import { PageTransition } from "@/components/PageTransition";
import { cn } from "@/lib/utils";
import { useToast } from "@/hooks/use-toast";

const TYPE_LABELS: Record<
  string,
  { ha: string; en: string; fromLabelHa: string; fromLabelEn: string; toLabelHa: string; toLabelEn: string }
> = {
  send:    { ha: "Aika Kuɗi",      en: "Money Sent",       fromLabelHa: "Daga",     fromLabelEn: "From",         toLabelHa: "Zuwa",       toLabelEn: "To"           },
  receive: { ha: "An Karɓi Kuɗi",  en: "Money Received",   fromLabelHa: "Daga",     fromLabelEn: "From",         toLabelHa: "Zuwa",       toLabelEn: "To"           },
  airtime: { ha: "Katin Waya",      en: "Airtime",          fromLabelHa: "Hanyar",   fromLabelEn: "Network",      toLabelHa: "Lambar",     toLabelEn: "Number"       },
  bill:    { ha: "Biyan Lissafi",   en: "Bill Payment",     fromLabelHa: "Mai Karɓa",fromLabelEn: "Provider",     toLabelHa: "Asusun",     toLabelEn: "Account"      },
  deposit: { ha: "Ajiya",           en: "Deposit",          fromLabelHa: "Daga",     fromLabelEn: "From",         toLabelHa: "Zuwa",       toLabelEn: "To"           },
};

const HERO_COLORS: Record<string, string> = {
  send:    "from-[#1e2b4f] to-[#2B3A67]",
  receive: "from-[#1e2b4f] to-[#2B3A67]",
  airtime: "from-[#1a4d8f] to-[#2563c7]",
  bill:    "from-[#7a3b1e] to-[#C97B4A]",
  deposit: "from-[#1e2b4f] to-[#2B3A67]",
};

const STATUS_CONFIG = {
  completed: {
    icon: CheckCircle2,
    pillClass: "bg-white/20 backdrop-blur-sm",
    badgeClass: "bg-[#E4E8F2] border-[#2B3A67]/25 text-[#2B3A67]",
    dotClass: "bg-[#2B3A67]",
    labelHa: "Ciniki Ya Yi",
    labelEn: "Completed",
  },
  pending: {
    icon: Clock,
    pillClass: "bg-[#C97B4A]/30 backdrop-blur-sm",
    badgeClass: "bg-[#F3E4D9] border-[#C97B4A]/30 text-[#C97B4A]",
    dotClass: "bg-[#C97B4A]",
    labelHa: "Ana Jira",
    labelEn: "Pending",
  },
  failed: {
    icon: XCircle,
    pillClass: "bg-red-500/30 backdrop-blur-sm",
    badgeClass: "bg-red-50 border-red-200 text-red-700",
    dotClass: "bg-red-500",
    labelHa: "Bai Yi Ba",
    labelEn: "Failed",
  },
} satisfies Record<string, { icon: React.ElementType; pillClass: string; badgeClass: string; dotClass: string; labelHa: string; labelEn: string }>;

export default function TransactionReceipt() {
  const { id } = useParams<{ id: string }>();
  const { toast } = useToast();

  const txn = MOCK_TRANSACTIONS.find((t) => t.id === id);

  if (!txn) {
    return (
      <PageTransition className="flex flex-col min-h-screen bg-background items-center justify-center gap-4 px-8">
        <p className="text-lg font-bold text-foreground text-center">
          Ba a sami ciniki ba
        </p>
        <p className="text-sm text-muted-foreground text-center">
          Transaction not found
        </p>
        <Link href="/" className="mt-2 text-primary font-semibold text-sm underline">
          Koma Gida / Go Home
        </Link>
      </PageTransition>
    );
  }

  const isCredit = txn.amount > 0;
  const label = TYPE_LABELS[txn.type];
  const heroGradient = HERO_COLORS[txn.type];
  const statusCfg = STATUS_CONFIG[txn.status];
  const StatusIcon = statusCfg.icon;

  const fromName = txn.type === "receive" ? txn.name : "Ibrahim Bello (Ni / Me)";
  const toName =
    txn.type === "send"    ? txn.name :
    txn.type === "airtime" ? (txn.account ?? txn.name) :
    txn.type === "bill"    ? txn.name :
    txn.type === "receive" ? "Ibrahim Bello (Ni / Me)" :
    txn.name;

  const safeCopy = async (text: string) => {
    try {
      if (navigator.clipboard?.writeText) {
        await navigator.clipboard.writeText(text);
      }
    } catch {
      // clipboard unavailable — silent fail; toast still shows
    }
  };

  const handleCopy = async () => {
    await safeCopy(txn.reference);
    toast({ description: "An kwafe lambar / Reference copied", duration: 2000 });
  };

  const handleShare = async () => {
    const text =
      `Arewa Pay Receipt\n` +
      `${label.en} — ₦${Math.abs(txn.amount).toLocaleString()}\n` +
      `Ref: ${txn.reference}\n` +
      `${txn.timestamp}`;
    if (typeof navigator.share === "function") {
      try {
        await navigator.share({ title: "Arewa Pay Receipt", text });
        return;
      } catch {
        // user dismissed or share unavailable — fall through to copy
      }
    }
    await safeCopy(text);
    toast({ description: "An kwafe takardar / Receipt copied", duration: 2000 });
  };

  return (
    <PageTransition className="flex flex-col min-h-screen bg-muted/30">
      {/* Hero header — gradient like BalanceCard */}
      <div className={cn("bg-gradient-to-br pt-safe text-white px-5 pt-12 pb-10 relative overflow-hidden", heroGradient)}>
        {/* Decorative blobs */}
        <div className="absolute top-0 right-0 -mr-10 -mt-10 w-40 h-40 rounded-full bg-white/10 blur-2xl pointer-events-none" />
        <div className="absolute bottom-0 left-0 -ml-6 -mb-6 w-28 h-28 rounded-full bg-black/10 blur-xl pointer-events-none" />

        {/* Back button */}
        <Link
          href="/"
          className="absolute top-10 left-5 w-10 h-10 rounded-full bg-white/20 flex items-center justify-center active:scale-95 transition-transform"
          aria-label="Koma baya / Go back"
        >
          <ArrowLeft className="w-5 h-5 text-white" />
        </Link>

        {/* Amount */}
        <div className="flex flex-col items-center text-center mt-6">
          <p className="text-white/70 text-sm font-medium mb-1">
            {label.ha} / {label.en}
          </p>
          <p className="text-4xl font-bold tracking-tight">
            {isCredit ? "+" : "-"}₦
            {Math.abs(txn.amount).toLocaleString(undefined, {
              minimumFractionDigits: 2,
              maximumFractionDigits: 2,
            })}
          </p>

          {/* Status pill — data-driven from txn.status */}
          <div className={cn("mt-4 flex items-center gap-1.5 px-3 py-1.5 rounded-full", statusCfg.pillClass)}>
            <StatusIcon className="w-4 h-4 text-white" />
            <span className="text-xs font-semibold text-white">
              {statusCfg.labelHa} / {statusCfg.labelEn}
            </span>
          </div>
        </div>
      </div>

      {/* Details card */}
      <div className="flex-1 -mt-4 bg-background rounded-t-3xl px-5 pt-6 pb-6 shadow-[0_-4px_24px_rgba(0,0,0,0.06)]">
        <h2 className="text-sm font-semibold text-muted-foreground uppercase tracking-wider mb-4">
          Bayanan Ciniki / Transaction Details
        </h2>

        <div className="bg-card border border-border rounded-3xl overflow-hidden shadow-sm divide-y divide-border/50">
          {/* From */}
          <Row
            labelHa={label.fromLabelHa}
            labelEn={label.fromLabelEn}
            value={fromName}
          />

          {/* To */}
          <Row
            labelHa={label.toLabelHa}
            labelEn={label.toLabelEn}
            value={toName}
          />

          {/* Date & Time */}
          <Row
            labelHa="Ranar Ciniki"
            labelEn="Date & Time"
            value={txn.timestamp}
          />

          {/* Type */}
          <Row
            labelHa="Nau'in Ciniki"
            labelEn="Transaction Type"
            value={`${label.ha} / ${label.en}`}
          />

          {/* Status — data-driven from txn.status */}
          <div className="flex items-center justify-between px-4 py-3.5">
            <div>
              <p className="text-xs text-muted-foreground font-medium">Yanayi</p>
              <p className="text-xs text-muted-foreground/70">Status</p>
            </div>
            <div className={cn("flex items-center gap-1.5 border px-3 py-1 rounded-full", statusCfg.badgeClass)}>
              <span className={cn("w-1.5 h-1.5 rounded-full", statusCfg.dotClass)} />
              <span className="text-xs font-semibold">
                {statusCfg.labelHa} / {statusCfg.labelEn}
              </span>
            </div>
          </div>

          {/* Reference */}
          <div className="flex items-center justify-between px-4 py-3.5">
            <div>
              <p className="text-xs text-muted-foreground font-medium">Lambar Ciniki</p>
              <p className="text-xs text-muted-foreground/70">Reference</p>
            </div>
            <button
              onClick={handleCopy}
              className="flex items-center gap-2 active:opacity-70 transition-opacity"
              aria-label="Kwafa lambar / Copy reference"
            >
              <span className="font-mono text-sm font-semibold text-foreground">
                {txn.reference}
              </span>
              <Copy className="w-3.5 h-3.5 text-primary" />
            </button>
          </div>
        </div>

        {/* Action buttons */}
        <div className="mt-6 flex gap-3">
          <Link
            href="/"
            className="flex-1 py-3.5 rounded-2xl border border-border bg-card font-semibold text-sm text-foreground text-center active:scale-[0.98] transition-transform"
          >
            Koma Gida / Home
          </Link>
          <button
            onClick={handleShare}
            className="flex-1 py-3.5 rounded-2xl bg-primary text-primary-foreground font-semibold text-sm flex items-center justify-center gap-2 active:scale-[0.98] transition-transform"
          >
            <Share2 className="w-4 h-4" />
            Raba / Share
          </button>
        </div>
      </div>
    </PageTransition>
  );
}

function Row({
  labelHa,
  labelEn,
  value,
}: {
  labelHa: string;
  labelEn: string;
  value: string;
}) {
  return (
    <div className="flex items-center justify-between px-4 py-3.5 gap-4">
      <div className="shrink-0">
        <p className="text-xs text-muted-foreground font-medium">{labelHa}</p>
        <p className="text-xs text-muted-foreground/70">{labelEn}</p>
      </div>
      <p className="text-sm font-semibold text-foreground text-right leading-snug">
        {value}
      </p>
    </div>
  );
}
