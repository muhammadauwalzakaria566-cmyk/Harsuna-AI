import { ArrowLeft, Phone, Wifi, Check } from "lucide-react";
import { Link } from "wouter";
import { useState } from "react";
import { cn } from "@/lib/utils";
import { useToast } from "@/hooks/use-toast";
import { PageTransition } from "@/components/PageTransition";

const NETWORKS = [
  { id: "mtn",     name: "MTN",     color: "bg-yellow-400",    text: "text-yellow-900", ring: "ring-yellow-400" },
  { id: "airtel",  name: "Airtel",  color: "bg-red-500",       text: "text-white",      ring: "ring-red-500" },
  { id: "glo",     name: "Glo",     color: "bg-[#E4E8F2]",     text: "text-[#2B3A67]",  ring: "ring-[#2B3A67]" },
  { id: "9mobile", name: "9mobile", color: "bg-[#2B3A67]",     text: "text-white",      ring: "ring-[#2B3A67]" },
];

const AIRTIME_PRESETS = ["100", "200", "500", "1000", "2000", "5000"];

const DATA_PLANS = [
  { id: "d1", label: "500 MB",  price: "₦200",  duration: "Rana 1 / 1 Day" },
  { id: "d2", label: "1 GB",    price: "₦350",  duration: "Kwana 7 / 7 Days" },
  { id: "d3", label: "2 GB",    price: "₦600",  duration: "Wata 1 / 1 Month" },
  { id: "d4", label: "5 GB",    price: "₦1,500",duration: "Wata 1 / 1 Month" },
  { id: "d5", label: "10 GB",   price: "₦2,500",duration: "Wata 1 / 1 Month" },
  { id: "d6", label: "20 GB",   price: "₦4,500",duration: "Wata 1 / 1 Month" },
];

export default function Airtime() {
  const { toast } = useToast();
  const [tab, setTab] = useState<"airtime" | "data">("airtime");
  const [network, setNetwork] = useState<string | null>(null);
  const [phone, setPhone] = useState("");
  const [amount, setAmount] = useState("");
  const [selectedPlan, setSelectedPlan] = useState<string | null>(null);

  const canContinue = network && phone.length >= 10 && (tab === "airtime" ? Number(amount) > 0 : !!selectedPlan);

  const handleContinue = () => {
    if (!canContinue) return;
    toast({
      description: tab === "airtime"
        ? `An aika ₦${Number(amount).toLocaleString()} airtime zuwa ${phone}`
        : `An tabbatar da siyan data zuwa ${phone}`,
      duration: 3000,
    });
  };

  return (
    <PageTransition className="flex flex-col min-h-screen bg-background pb-8">
      {/* Header */}
      <header className="px-5 pt-8 pb-4 flex items-center gap-4 sticky top-0 bg-background/90 backdrop-blur-md z-10 border-b border-border/40">
        <Link href="/" className="w-10 h-10 rounded-full bg-card border border-border flex items-center justify-center shrink-0 active:scale-95 transition-transform">
          <ArrowLeft className="w-5 h-5 text-foreground" />
        </Link>
        <div>
          <h1 className="text-lg font-bold text-foreground leading-tight">Airtime & Data</h1>
          <p className="text-xs text-muted-foreground font-medium">Katin Waya</p>
        </div>
      </header>

      <main className="flex-1 px-5 pt-5 flex flex-col gap-5">

        {/* Tab Toggle */}
        <div className="flex bg-muted rounded-2xl p-1">
          <button
            data-testid="tab-airtime"
            onClick={() => setTab("airtime")}
            className={cn(
              "flex-1 flex items-center justify-center gap-2 py-2.5 rounded-xl text-sm font-semibold transition-all",
              tab === "airtime"
                ? "bg-card text-primary shadow-sm"
                : "text-muted-foreground"
            )}
          >
            <Phone className="w-4 h-4" />
            Airtime
          </button>
          <button
            data-testid="tab-data"
            onClick={() => setTab("data")}
            className={cn(
              "flex-1 flex items-center justify-center gap-2 py-2.5 rounded-xl text-sm font-semibold transition-all",
              tab === "data"
                ? "bg-card text-primary shadow-sm"
                : "text-muted-foreground"
            )}
          >
            <Wifi className="w-4 h-4" />
            Data
          </button>
        </div>

        {/* Network Selection */}
        <section>
          <p className="text-sm font-semibold text-foreground mb-3">
            Zaɓi Hanyar Sadarwa / Select Network
          </p>
          <div className="grid grid-cols-4 gap-3">
            {NETWORKS.map((n) => (
              <button
                key={n.id}
                data-testid={`network-${n.id}`}
                onClick={() => setNetwork(n.id)}
                className={cn(
                  "flex flex-col items-center gap-2 py-3 rounded-2xl border-2 transition-all active:scale-95",
                  network === n.id
                    ? "border-primary bg-primary/5"
                    : "border-border bg-card"
                )}
              >
                <div className={cn("w-10 h-10 rounded-full flex items-center justify-center font-bold text-xs", n.color, n.text)}>
                  {n.name}
                </div>
                {network === n.id && (
                  <div className="w-4 h-4 bg-primary rounded-full flex items-center justify-center">
                    <Check className="w-2.5 h-2.5 text-primary-foreground" />
                  </div>
                )}
              </button>
            ))}
          </div>
        </section>

        {/* Phone Number */}
        <section>
          <p className="text-sm font-semibold text-foreground mb-2">
            Lambar Waya / Phone Number
          </p>
          <input
            data-testid="input-phone"
            type="tel"
            value={phone}
            onChange={(e) => setPhone(e.target.value.replace(/\D/g, "").slice(0, 11))}
            placeholder="e.g. 08012345678"
            className="w-full h-12 px-4 bg-card border border-border rounded-xl text-sm outline-none focus:border-primary focus:ring-1 focus:ring-primary transition-all placeholder:text-muted-foreground"
          />
          <p className="text-xs text-muted-foreground mt-1.5">Lambar mai karɓa / Recipient's number</p>
        </section>

        {tab === "airtime" ? (
          <>
            {/* Preset Amounts */}
            <section>
              <p className="text-sm font-semibold text-foreground mb-3">
                Zaɓi Adadin Kuɗi / Choose Amount (₦)
              </p>
              <div className="grid grid-cols-3 gap-3 mb-4">
                {AIRTIME_PRESETS.map((preset) => (
                  <button
                    key={preset}
                    data-testid={`preset-${preset}`}
                    onClick={() => setAmount(preset)}
                    className={cn(
                      "py-3 rounded-xl border text-sm font-semibold transition-all active:scale-95",
                      amount === preset
                        ? "border-primary bg-primary text-primary-foreground"
                        : "border-border bg-card text-foreground hover:border-primary/50"
                    )}
                  >
                    ₦{Number(preset).toLocaleString()}
                  </button>
                ))}
              </div>

              {/* Custom amount */}
              <div className="relative">
                <span className="absolute inset-y-0 left-4 flex items-center text-muted-foreground font-semibold text-sm">₦</span>
                <input
                  data-testid="input-custom-amount"
                  type="number"
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                  placeholder="Ko shigar da adadi / Or enter custom amount"
                  className="w-full h-12 pl-8 pr-4 bg-card border border-border rounded-xl text-sm outline-none focus:border-primary focus:ring-1 focus:ring-primary transition-all placeholder:text-muted-foreground"
                />
              </div>
            </section>
          </>
        ) : (
          /* Data Plans */
          <section>
            <p className="text-sm font-semibold text-foreground mb-3">
              Zaɓi Shirin Data / Select Data Plan
            </p>
            <div className="flex flex-col gap-3">
              {DATA_PLANS.map((plan) => (
                <button
                  key={plan.id}
                  data-testid={`plan-${plan.id}`}
                  onClick={() => setSelectedPlan(plan.id)}
                  className={cn(
                    "flex items-center justify-between p-4 rounded-2xl border-2 transition-all active:scale-[0.98] text-left",
                    selectedPlan === plan.id
                      ? "border-primary bg-primary/5"
                      : "border-border bg-card"
                  )}
                >
                  <div>
                    <p className="font-bold text-foreground text-base">{plan.label}</p>
                    <p className="text-xs text-muted-foreground mt-0.5">{plan.duration}</p>
                  </div>
                  <div className="flex items-center gap-3">
                    <span className={cn("text-lg font-bold", selectedPlan === plan.id ? "text-primary" : "text-foreground")}>
                      {plan.price}
                    </span>
                    {selectedPlan === plan.id && (
                      <div className="w-5 h-5 bg-primary rounded-full flex items-center justify-center shrink-0">
                        <Check className="w-3 h-3 text-primary-foreground" />
                      </div>
                    )}
                  </div>
                </button>
              ))}
            </div>
          </section>
        )}
      </main>

      {/* Continue Button */}
      <div className="px-5 pt-6">
        <button
          data-testid="button-continue"
          onClick={handleContinue}
          className={cn(
            "w-full py-4 rounded-2xl font-bold text-lg shadow-sm transition-all active:scale-[0.98]",
            canContinue
              ? "bg-primary text-primary-foreground"
              : "bg-muted text-muted-foreground cursor-not-allowed"
          )}
        >
          Ci Gaba / Continue
        </button>
      </div>
    </PageTransition>
  );
}
