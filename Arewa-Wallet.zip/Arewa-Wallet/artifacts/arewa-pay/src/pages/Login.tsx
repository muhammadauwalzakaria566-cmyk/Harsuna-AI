import { useState } from "react";
import { Link, useLocation } from "wouter";
import { Delete } from "lucide-react";
import { useAuth } from "@/context/AuthContext";
import { cn } from "@/lib/utils";

const PAD_KEYS = ["1","2","3","4","5","6","7","8","9","","0","del"] as const;

export default function Login() {
  const { login } = useAuth();
  const [, setLocation] = useLocation();
  const [phone, setPhone] = useState("");
  const [pin, setPin] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const handlePad = (key: string) => {
    if (key === "del") {
      setPin((p) => p.slice(0, -1));
    } else if (pin.length < 4) {
      setPin((p) => p + key);
    }
  };

  const handleSubmit = async () => {
    if (!phone.trim() || pin.length !== 4) return;
    setError("");
    setLoading(true);
    try {
      await login(phone.trim(), pin);
      setLocation("/");
    } catch (e: unknown) {
      setError(e instanceof Error ? e.message : "Kuskure / Error occurred");
      setPin("");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex flex-col h-[100dvh] bg-background font-sans">
      {/* Indigo header */}
      <div className="bg-gradient-to-br from-[#1e2b4f] to-[#2B3A67] px-6 pt-14 pb-10 text-white flex flex-col items-center relative overflow-hidden">
        <div className="absolute top-0 right-0 w-48 h-48 rounded-full bg-white/10 -mr-12 -mt-12 blur-2xl pointer-events-none" />
        <div className="absolute bottom-0 left-0 w-32 h-32 rounded-full bg-black/10 -ml-8 -mb-8 blur-xl pointer-events-none" />
        <div className="w-16 h-16 rounded-3xl bg-white/20 flex items-center justify-center mb-4 text-3xl font-black relative">
          A
        </div>
        <h1 className="text-2xl font-bold">Arewa Pay</h1>
        <p className="text-white/70 text-sm mt-1">Shiga asusunka / Sign in to your account</p>
      </div>

      {/* Card */}
      <div className="flex-1 bg-background rounded-t-3xl -mt-4 px-5 pt-6 pb-4 overflow-y-auto shadow-[0_-4px_24px_rgba(0,0,0,0.06)] flex flex-col gap-4">
        {/* Phone field */}
        <div>
          <label className="text-xs font-semibold text-muted-foreground mb-1.5 block">
            Lambar Waya / Phone Number
          </label>
          <input
            type="tel"
            inputMode="tel"
            placeholder="080 0000 0000"
            value={phone}
            onChange={(e) => setPhone(e.target.value)}
            className="w-full h-12 px-4 rounded-2xl border border-border bg-card text-foreground text-sm font-medium outline-none focus:border-primary focus:ring-2 focus:ring-primary/20 transition-all"
          />
        </div>

        {/* PIN dots */}
        <div>
          <label className="text-xs font-semibold text-muted-foreground mb-3 block">
            PIN
          </label>
          <div className="flex items-center justify-center gap-5 mb-4">
            {[0, 1, 2, 3].map((i) => (
              <div
                key={i}
                className={cn(
                  "w-4 h-4 rounded-full border-2 transition-all duration-150",
                  i < pin.length
                    ? "bg-primary border-primary scale-110"
                    : "border-border",
                )}
              />
            ))}
          </div>

          {/* Numpad */}
          <div className="grid grid-cols-3 gap-3">
            {PAD_KEYS.map((key, idx) => {
              if (key === "") return <div key={idx} />;
              return (
                <button
                  key={idx}
                  onClick={() => handlePad(key)}
                  disabled={loading}
                  className={cn(
                    "h-14 rounded-2xl font-semibold text-lg transition-all active:scale-95 select-none",
                    key === "del"
                      ? "bg-muted text-foreground"
                      : "bg-card border border-border text-foreground hover:bg-muted/60",
                  )}
                >
                  {key === "del" ? (
                    <Delete className="w-5 h-5 mx-auto" />
                  ) : (
                    key
                  )}
                </button>
              );
            })}
          </div>
        </div>

        {/* Error */}
        {error && (
          <p className="text-xs text-destructive font-medium text-center px-2 bg-destructive/5 py-2 rounded-xl">
            {error}
          </p>
        )}

        {/* Submit */}
        <button
          onClick={handleSubmit}
          disabled={loading || !phone.trim() || pin.length !== 4}
          className="w-full h-13 rounded-2xl bg-primary text-primary-foreground font-bold text-base transition-all active:scale-[0.98] disabled:opacity-50 py-3.5"
        >
          {loading ? "Ana shiga..." : "Shiga / Sign In"}
        </button>

        {/* Link to signup */}
        <p className="text-center text-sm text-muted-foreground">
          Ba ka da asusun?{" "}
          <Link href="/signup" className="text-primary font-semibold">
            Yi Rajista / Sign Up
          </Link>
        </p>
      </div>
    </div>
  );
}
