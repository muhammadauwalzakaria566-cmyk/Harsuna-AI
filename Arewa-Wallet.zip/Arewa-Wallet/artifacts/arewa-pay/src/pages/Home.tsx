import { Bell } from "lucide-react";
import { Link } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { BalanceCard } from "@/components/BalanceCard";
import { QuickActions } from "@/components/QuickActions";
import { TransactionItem, MOCK_TRANSACTIONS } from "@/components/TransactionItem";
import { DbTransactionRow } from "@/components/DbTransactionRow";
import { PageTransition } from "@/components/PageTransition";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { useAuth } from "@/context/AuthContext";
import { api, type AuthUser, type ApiTransaction } from "@/lib/api";
import { Skeleton } from "@/components/ui/skeleton";

export default function Home() {
  const { user } = useAuth();

  const { data: freshUser } = useQuery<AuthUser>({
    queryKey: ["auth", "me"],
    queryFn: () => api.get<AuthUser>("/auth/me"),
    staleTime: 30_000,
  });

  const { data: transactions, isLoading: txLoading } = useQuery<ApiTransaction[]>({
    queryKey: ["transactions"],
    queryFn: () => api.get<ApiTransaction[]>("/transactions"),
    staleTime: 30_000,
  });

  const displayUser = freshUser ?? user;
  const balance = displayUser?.balance ?? "0.00";
  const initials = displayUser?.fullName
    ? displayUser.fullName
        .split(" ")
        .map((w) => w[0])
        .join("")
        .slice(0, 2)
        .toUpperCase()
    : "AP";

  const greeting = displayUser?.fullName?.split(" ")[0] ?? "Ku";
  const recentTxns = (transactions ?? []).slice(0, 5);
  const hasTxns = recentTxns.length > 0;

  return (
    <PageTransition className="flex flex-col min-h-screen bg-background">
      {/* Header */}
      <header className="px-5 pt-8 pb-4 flex justify-between items-center sticky top-0 bg-background/80 backdrop-blur-md z-10">
        <div className="flex items-center gap-3">
          <Link href="/profile">
            <Avatar className="w-10 h-10 border-2 border-border cursor-pointer">
              <AvatarImage src="" />
              <AvatarFallback className="bg-primary/10 text-primary font-bold">
                {initials}
              </AvatarFallback>
            </Avatar>
          </Link>
          <div>
            <h1 className="text-lg font-bold text-foreground tracking-tight">
              Sannu, {greeting}
            </h1>
            <p className="text-xs text-muted-foreground font-medium">
              {new Date().toLocaleDateString("en-NG", { weekday: "long" })}
            </p>
          </div>
        </div>
        <Link
          href="/notifications"
          className="w-10 h-10 rounded-full bg-card border border-border flex items-center justify-center relative shadow-sm active:scale-95 transition-transform"
        >
          <Bell className="w-5 h-5 text-foreground" />
          <span className="absolute top-2.5 right-2.5 w-2 h-2 rounded-full bg-accent border-2 border-card" />
        </Link>
      </header>

      <main className="flex-1 px-5 flex flex-col gap-6">
        {/* Balance */}
        <section>
          <BalanceCard balance={balance} accountNumber={displayUser?.accountNumber} />
        </section>

        {/* Quick Actions */}
        <section>
          <QuickActions />
        </section>

        {/* Recent Transactions */}
        <section className="bg-card border border-border rounded-3xl p-5 shadow-sm mb-4">
          <div className="flex justify-between items-center mb-4">
            <h3 className="font-bold text-foreground">
              Ciniki Na Kwanan Nan{" "}
              <br />
              <span className="text-xs text-muted-foreground font-normal">
                Recent Transactions
              </span>
            </h3>
            <Link href="/history" className="text-primary text-sm font-semibold hover:underline">
              Duba Duka
            </Link>
          </div>

          {txLoading ? (
            <div className="flex flex-col gap-3">
              {[1, 2, 3].map((i) => (
                <div key={i} className="flex items-center gap-3 py-1">
                  <Skeleton className="w-11 h-11 rounded-full" />
                  <div className="flex-1 space-y-1.5">
                    <Skeleton className="h-3.5 w-32 rounded" />
                    <Skeleton className="h-3 w-24 rounded" />
                  </div>
                  <Skeleton className="h-3.5 w-16 rounded" />
                </div>
              ))}
            </div>
          ) : hasTxns ? (
            <div className="flex flex-col divide-y divide-border/50">
              {recentTxns.map((t) => (
                <DbTransactionRow key={t.id} txn={t} />
              ))}
            </div>
          ) : (
            /* Empty state — fall back to mock demo data so new users see something */
            <div className="flex flex-col divide-y divide-border/50">
              {MOCK_TRANSACTIONS.slice(0, 3).map((t) => (
                <TransactionItem key={t.id} transaction={t} />
              ))}
              <p className="pt-3 text-center text-xs text-muted-foreground/60">
                Waɗannan misalai ne / These are demo transactions
              </p>
            </div>
          )}
        </section>
      </main>
    </PageTransition>
  );
}
