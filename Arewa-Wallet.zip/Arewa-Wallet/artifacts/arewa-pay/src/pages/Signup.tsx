import { useState } from "react";
import { Link, useLocation } from "wouter";
import { ArrowLeft, Delete } from "lucide-react";
import { useAuth } from "@/context/AuthContext";
import { cn } from "@/lib/utils";

const PAD_KEYS = ["1","2","3","4","5","6","7","8","9","","0","del"] as const;

type Step = "details" | "pin" | "confirm";

export default function Signup() {
  const { signup } = useAuth();
  const [, setLocation] = useLocation();

  const [step, setStep] = useState<Step>("details");
  const [fullName, setFullName] = useState("");
  const [phone, setPhone] = useState("");
  const [pin, setPin] = useState("");
  const [confirmPin, setConfirmPin] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const activePin = step === "pin" ? pin : confirmPin;
  const setActivePin = step === "pin" ? setPin : setConfirmPin;

  const handlePad = (key: string) => {
    if (key === "del") {
      setActivePin((p) => p.slice(0, -1));
    } else if (activePin.length < 4) {
      setActivePin((p) => p + key);
    }
  };

  const handleDetailsNext = () => {
    setError("");
    if (!fullName.trim()) { setError("Shigar da sunanku / Enter your full name"); return; }
    if (!phone.trim()) { setError("Shigar da lambar waya / Enter phone number"); return; }
    const cleaned = phone.trim().replace(/\s/g, "");
    if (!/^(\+234|0)\d{10}$/.test(cleaned)) { setError("Lambar waya ba daidai ba / Invalid phone number"); return; }
    setStep("pin");
  };

  const handlePinNext = () => {
    setError("");
    if (pin.length !== 4) { setError("Shigar da PIN mai lamba 4 / Enter a 4-digit PIN"); return; }
    setStep("confirm");
  };

  const handleSubmit = async () => {
    setError("");
    if (confirmPin !== pin) {
      setError("PIN ba ɗaya ba / PINs do not match");
      setConfirmPin("");
      return;
    }
    setLoading(true);
    try {
      await signup(phone.trim(), fullName.trim(), pin);
      setLocation("/");
    } catch (e: unknown) {
      setError(e instanceof Error ? e.message : "Kuskure / An error occurred");
      setLoading(false);
    }
  };

  const stepNum = step === "details" ? 1 : step === "pin" ? 2 : 3;
  const stepTotal = 3;

  return (
    <div className="flex flex-col h-[100dvh] bg-background font-sans">
      {/* Indigo header */}
      <div className="bg-gradient-to-br from-[#1e2b4f] to-[#2B3A67] px-6 pt-12 pb-8 text-white relative overflow-hidden">
        <div className="absolute top-0 right-0 w-48 h-48 rounded-full bg-white/10 -mr-12 -mt-12 blur-2xl pointer-events-none" />

        {/* Back / close */}
        <div className="flex items-center justify-between mb-5 relative">
          <button
            onClick={() => {
              if (step === "confirm") { setStep("pin"); setConfirmPin(""); setError(""); }
              else if (step === "pin") { setStep("details"); setPin(""); setError(""); }
              else setLocation("/login");
            }}
            className="w-9 h-9 rounded-full bg-white/20 flex items-center justify-center"
            aria-label="Koma baya / Go back"
          >
            <ArrowLeft className="w-4 h-4 text-white" />
          </button>

          {/* Step dots */}
          <div className="flex gap-1.5">
            {[1, 2, 3].map((s) => (
              <div
                key={s}
                className={cn(
                  "h-1.5 rounded-full transition-all",
                  s === stepNum ? "w-6 bg-white" : "w-1.5 bg-white/40",
                )}
              />
            ))}
          </div>
          <div className="w-9" />
        </div>

        <h1 className="text-xl font-bold">
          {step === "details" && "Bayanan Ka / Your Details"}
          {step === "pin" && "Ƙirƙira PIN / Create PIN"}
          {step === "confirm" && "Tabbatar da PIN / Confirm PIN"}
        </h1>
        <p className="text-white/70 text-sm mt-0.5">
          {step === "details" && "Mataki {stepNum} daga {stepTotal} / Step 1 of 3".replace("{stepNum}", String(stepNum)).replace("{stepTotal}", String(stepTotal))}
          {step === "pin" && "Shigar da PIN mai lamba 4 / Enter a 4-digit PIN"}
          {step === "confirm" && "Sake shigar da PIN don tabbatarwa / Re-enter your PIN"}
        </p>
      </div>

      {/* Card */}
      <div className="flex-1 bg-background rounded-t-3xl -mt-4 px-5 pt-6 pb-4 overflow-y-auto shadow-[0_-4px_24px_rgba(0,0,0,0.06)] flex flex-col gap-4">
        {/* ── Step 1: Details ── */}
        {step === "details" && (
          <>
            <div>
              <label className="text-xs font-semibold text-muted-foreground mb-1.5 block">
                Cikakken Suna / Full Name
              </label>
              <input
                type="text"
                placeholder="Ibrahim Bello"
                value={fullName}
                onChange={(e) => setFullName(e.target.value)}
                className="w-full h-12 px-4 rounded-2xl border border-border bg-card text-foreground text-sm font-medium outline-none focus:border-primary focus:ring-2 focus:ring-primary/20 transition-all"
              />
            </div>
            <div>
              <label className="text-xs font-semibold text-muted-foreground mb-1.5 block">
                Lambar Waya / Phone Number
              </label>
              <input
                type="tel"
                inputMode="tel"
                placeholder="080 0000 0000"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                className="w-full h-12 px-4 rounded-2xl border border-border bg-card text-foreground text-sm font-medium outline-none focus:border-primary focus:ring-2 focus:ring-primary/20 transition-all"
              />
            </div>

            {error && (
              <p className="text-xs text-destructive font-medium text-center bg-destructive/5 py-2 rounded-xl px-2">
                {error}
              </p>
            )}

            <button
              onClick={handleDetailsNext}
              className="w-full py-3.5 rounded-2xl bg-primary text-primary-foreground font-bold text-base active:scale-[0.98] transition-all"
            >
              Ci Gaba / Continue
            </button>

            <p className="text-center text-sm text-muted-foreground">
              Kana da asusun?{" "}
              <Link href="/login" className="text-primary font-semibold">
                Shiga / Sign In
              </Link>
            </p>
          </>
        )}

        {/* ── Step 2 & 3: PIN entry ── */}
        {(step === "pin" || step === "confirm") && (
          <>
            {/* PIN dots */}
            <div className="flex items-center justify-center gap-5 py-4">
              {[0, 1, 2, 3].map((i) => (
                <div
                  key={i}
                  className={cn(
                    "w-5 h-5 rounded-full border-2 transition-all duration-150",
                    i < activePin.length
                      ? "bg-primary border-primary scale-110"
                      : "border-border",
                  )}
                />
              ))}
            </div>

            {/* Numpad */}
            <div className="grid grid-cols-3 gap-3">
              {PAD_KEYS.map((key, idx) => {
                if (key === "") return <div key={idx} />;
                return (
                  <button
                    key={idx}
                    onClick={() => handlePad(key)}
                    disabled={loading}
                    className={cn(
                      "h-14 rounded-2xl font-semibold text-lg transition-all active:scale-95 select-none",
                      key === "del"
                        ? "bg-muted text-foreground"
                        : "bg-card border border-border text-foreground hover:bg-muted/60",
                    )}
                  >
                    {key === "del" ? (
                      <Delete className="w-5 h-5 mx-auto" />
                    ) : (
                      key
                    )}
                  </button>
                );
              })}
            </div>

            {error && (
              <p className="text-xs text-destructive font-medium text-center bg-destructive/5 py-2 rounded-xl px-2">
                {error}
              </p>
            )}

            <button
              onClick={step === "pin" ? handlePinNext : handleSubmit}
              disabled={loading || activePin.length !== 4}
              className="w-full py-3.5 rounded-2xl bg-primary text-primary-foreground font-bold text-base active:scale-[0.98] transition-all disabled:opacity-50"
            >
              {loading
                ? "Ana rajista..."
                : step === "pin"
                ? "Ci Gaba / Continue"
                : "Yi Rajista / Create Account"}
            </button>
          </>
        )}
      </div>
    </div>
  );
}
