import { ArrowLeft, Search } from "lucide-react";
import { Link, useLocation } from "wouter";
import { PageTransition } from "@/components/PageTransition";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { useState } from "react";
import { cn } from "@/lib/utils";

const RECENT_RECIPIENTS = [
  { id: "1", name: "Aisha Musa", initials: "AM", color: "bg-orange-100 text-orange-700" },
  { id: "2", name: "Musa Sule", initials: "MS", color: "bg-blue-100 text-blue-700" },
  { id: "3", name: "Fatima B.", initials: "FB", color: "bg-purple-100 text-purple-700" },
  { id: "4", name: "Aminu K.", initials: "AK", color: "bg-[#E4E8F2] text-[#2B3A67]" },
];

export default function Send() {
  const [, setLocation] = useLocation();
  const [amount, setAmount] = useState("");
  const [note, setNote] = useState("");
  const [selectedRecipient, setSelectedRecipient] = useState<string | null>(null);

  const handleKeyPress = (key: string) => {
    if (key === 'backspace') {
      setAmount(prev => prev.slice(0, -1));
    } else if (amount === "0" && key !== ".") {
      setAmount(key);
    } else if (amount.includes(".") && key === ".") {
      return;
    } else if (amount.includes(".") && amount.split(".")[1].length >= 2) {
      return;
    } else {
      setAmount(prev => prev + key);
    }
  };

  return (
    <PageTransition className="flex flex-col min-h-screen pb-24 bg-background">
      <header className="px-5 pt-8 pb-4 flex items-center gap-4 sticky top-0 bg-background/80 backdrop-blur-md z-10">
        <Link href="/" className="w-10 h-10 rounded-full bg-card border border-border flex items-center justify-center shrink-0">
          <ArrowLeft className="w-5 h-5 text-foreground" />
        </Link>
        <div>
          <h1 className="text-lg font-bold text-foreground leading-tight">Aika Kuɗi</h1>
          <p className="text-xs text-muted-foreground font-medium">Send Money</p>
        </div>
      </header>

      <main className="flex-1 px-5 flex flex-col gap-6">
        {/* Search */}
        <div className="relative">
          <div className="absolute inset-y-0 left-4 flex items-center pointer-events-none">
            <Search className="h-5 w-5 text-muted-foreground" />
          </div>
          <input
            type="text"
            className="w-full h-12 pl-11 pr-4 bg-card border border-border rounded-xl text-sm outline-none focus:border-primary focus:ring-1 focus:ring-primary transition-all placeholder:text-muted-foreground"
            placeholder="Nemo mai karɓa / Search recipient"
          />
        </div>

        {/* Recent Recipients */}
        <section>
          <h3 className="text-sm font-semibold text-foreground mb-3">
            Masu Karɓa Na Kwanan Nan
          </h3>
          <div className="flex gap-4 overflow-x-auto pb-2 -mx-5 px-5 snap-x hide-scrollbar">
            {RECENT_RECIPIENTS.map((r) => (
              <button
                key={r.id}
                onClick={() => setSelectedRecipient(r.id)}
                className="flex flex-col items-center gap-2 snap-start outline-none"
              >
                <div className={cn(
                  "w-14 h-14 rounded-full flex items-center justify-center border-2 transition-all",
                  selectedRecipient === r.id ? "border-primary scale-105" : "border-transparent",
                  r.color
                )}>
                  <span className="font-bold text-lg">{r.initials}</span>
                </div>
                <span className="text-xs font-medium text-foreground w-16 text-center truncate">
                  {r.name}
                </span>
              </button>
            ))}
          </div>
        </section>

        {/* Amount Input */}
        <section className="bg-card border border-border rounded-3xl p-6 shadow-sm flex flex-col items-center justify-center mt-2">
          <p className="text-sm text-muted-foreground font-medium mb-2">Jimillar Kuɗi / Amount</p>
          <div className="flex items-center justify-center text-4xl font-bold tracking-tight text-foreground">
            <span className="text-muted-foreground mr-1">₦</span>
            {amount ? (
              <span>
                {Number(amount).toLocaleString(undefined, { minimumFractionDigits: amount.includes(".") ? amount.split(".")[1].length : 0 })}
              </span>
            ) : (
              <span className="text-muted-foreground/30">0.00</span>
            )}
          </div>

          <div className="w-full mt-6">
            <input
              type="text"
              value={note}
              onChange={(e) => setNote(e.target.value)}
              className="w-full bg-background border border-border rounded-xl px-4 py-3 text-sm text-center outline-none focus:border-primary focus:ring-1 focus:ring-primary transition-all placeholder:text-muted-foreground"
              placeholder="Ƙara Bayani / Add Note (Optional)"
            />
          </div>
        </section>

        {/* Custom Keypad */}
        <div className="mt-auto pt-4 pb-2">
          <div className="grid grid-cols-3 gap-y-6">
            {['1', '2', '3', '4', '5', '6', '7', '8', '9', '.', '0'].map((key) => (
              <button
                key={key}
                onClick={() => handleKeyPress(key)}
                className="text-2xl font-semibold text-foreground py-2 outline-none active:scale-90 transition-transform"
              >
                {key}
              </button>
            ))}
            <button
              onClick={() => handleKeyPress('backspace')}
              className="text-xl font-semibold text-foreground py-2 flex items-center justify-center outline-none active:scale-90 transition-transform"
            >
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d="m21 4H8l-7 8 7 8h13a2 2 0 0 0 2-2V6a2 2 0 0 0-2-2z" />
                <path d="m18 9-6 6" />
                <path d="m12 9 6 6" />
              </svg>
            </button>
          </div>
        </div>
      </main>

      <div className="fixed bottom-[84px] left-0 right-0 px-5 max-w-[430px] mx-auto z-10">
        <button 
          className={cn(
            "w-full py-4 rounded-2xl font-bold text-lg shadow-sm transition-all flex items-center justify-center",
            amount && Number(amount) > 0
              ? "bg-primary text-primary-foreground active:scale-[0.98]" 
              : "bg-muted text-muted-foreground cursor-not-allowed"
          )}
        >
          Ci Gaba / Continue
        </button>
      </div>
    </PageTransition>
  );
}
