import { PageTransition } from "@/components/PageTransition";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { ChevronRight, Globe, HelpCircle, LogOut, Shield } from "lucide-react";
import { cn } from "@/lib/utils";

const SETTINGS_ITEMS = [
  { icon: Shield, label: "Tsaro", sub: "Security", href: "#" },
  { icon: Globe, label: "Yaren App", sub: "Language", value: "Hausa / English", href: "#" },
  { icon: HelpCircle, label: "Taimako", sub: "Help & Support", href: "#" },
];

export default function Profile() {
  return (
    <PageTransition className="flex flex-col min-h-screen bg-background">
      <header className="px-5 pt-8 pb-4 text-center">
        <h1 className="text-xl font-bold text-foreground">Asusun</h1>
        <p className="text-sm text-muted-foreground">Profile</p>
      </header>

      <main className="flex-1 px-5 flex flex-col items-center">
        {/* Profile Card */}
        <div className="w-full bg-card border border-border rounded-3xl p-6 shadow-sm flex flex-col items-center mb-8 relative overflow-hidden">
          {/* Decor */}
          <div className="absolute top-0 left-0 w-full h-24 bg-primary/10 -z-10" />
          
          <Avatar className="w-24 h-24 border-4 border-card shadow-sm mb-4">
            <AvatarImage src="" />
            <AvatarFallback className="bg-primary text-primary-foreground text-3xl font-bold">IB</AvatarFallback>
          </Avatar>
          
          <h2 className="text-2xl font-bold text-foreground mb-1">Ibrahim Bello</h2>
          <p className="text-muted-foreground font-medium mb-3">+234 812 345 6789</p>
          
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-accent/10 text-accent-foreground text-xs font-semibold border border-accent/20">
            <span className="w-2 h-2 rounded-full bg-accent" />
            Arewa Pay Member since 2023
          </div>
        </div>

        {/* Settings List */}
        <div className="w-full bg-card border border-border rounded-3xl shadow-sm flex flex-col divide-y divide-border/50 overflow-hidden mb-6">
          {SETTINGS_ITEMS.map((item, i) => (
            <button key={i} className="flex items-center justify-between p-4 outline-none hover:bg-muted/50 transition-colors active:bg-muted">
              <div className="flex items-center gap-4">
                <div className="w-10 h-10 rounded-full bg-muted flex items-center justify-center shrink-0">
                  <item.icon className="w-5 h-5 text-foreground" />
                </div>
                <div className="text-left">
                  <p className="font-semibold text-foreground">{item.label}</p>
                  <p className="text-xs text-muted-foreground">{item.sub}</p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                {item.value && (
                  <span className="text-xs font-medium text-muted-foreground bg-background px-2 py-1 rounded-md border border-border">
                    {item.value}
                  </span>
                )}
                <ChevronRight className="w-5 h-5 text-muted-foreground" />
              </div>
            </button>
          ))}
        </div>

        {/* Logout */}
        <div className="w-full bg-card border border-border rounded-3xl shadow-sm overflow-hidden">
          <button className="flex items-center gap-4 p-4 w-full outline-none hover:bg-destructive/5 transition-colors active:bg-destructive/10">
            <div className="w-10 h-10 rounded-full bg-destructive/10 flex items-center justify-center shrink-0">
              <LogOut className="w-5 h-5 text-destructive" />
            </div>
            <div className="text-left flex-1">
              <p className="font-semibold text-destructive">Fita</p>
              <p className="text-xs text-destructive/70">Logout</p>
            </div>
          </button>
        </div>
      </main>
    </PageTransition>
  );
}
