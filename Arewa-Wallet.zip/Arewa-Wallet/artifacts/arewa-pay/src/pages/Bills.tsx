import {
  ArrowLeft,
  Zap,
  Droplets,
  Tv,
  Wifi,
  Home,
  ShoppingBag,
  ArrowRight,
  Check,
} from "lucide-react";
import { Link } from "wouter";
import { useState } from "react";
import { cn } from "@/lib/utils";
import { useToast } from "@/hooks/use-toast";
import { PageTransition } from "@/components/PageTransition";

const CATEGORIES = [
  { id: "electricity", en: "Electricity",   ha: "Wutar Lantarki",  icon: Zap,         color: "bg-[#F3E4D9] text-[#C97B4A]",  border: "border-[#C97B4A]/25" },
  { id: "water",       en: "Water",          ha: "Ruwa",             icon: Droplets,    color: "bg-blue-50 text-blue-600",      border: "border-blue-200" },
  { id: "tv",          en: "TV / Cable",     ha: "Talabijin",        icon: Tv,          color: "bg-purple-50 text-purple-600",  border: "border-purple-200" },
  { id: "internet",    en: "Internet",       ha: "Intanet",          icon: Wifi,        color: "bg-[#E4E8F2] text-[#2B3A67]",  border: "border-[#2B3A67]/20" },
  { id: "rent",        en: "Rent",           ha: "Haya",             icon: Home,        color: "bg-orange-50 text-orange-600",  border: "border-orange-200" },
  { id: "other",       en: "Other Bills",    ha: "Sauran Lissafi",   icon: ShoppingBag, color: "bg-muted text-muted-foreground",border: "border-border" },
];

const PROVIDERS: Record<string, { id: string; name: string }[]> = {
  electricity: [
    { id: "aedc",  name: "AEDC (Abuja)" },
    { id: "kano",  name: "Kano DISCO" },
    { id: "kaduna",name: "Kaduna DISCO" },
    { id: "sokoto",name: "Sokoto DISCO" },
  ],
  water: [
    { id: "fcda",  name: "FCDA Water Board" },
    { id: "kanow", name: "Kano State Water" },
    { id: "kadw",  name: "Kaduna Water" },
  ],
  tv: [
    { id: "dstv",    name: "DStv" },
    { id: "gotv",    name: "GOtv" },
    { id: "startimes",name: "StarTimes" },
  ],
  internet: [
    { id: "mtn_fiber",  name: "MTN Fiber" },
    { id: "airtel_fiber",name: "Airtel SmartConnect" },
    { id: "spectranet", name: "Spectranet" },
    { id: "swift",      name: "Swift Networks" },
  ],
  rent: [
    { id: "agent",  name: "Property Agent" },
    { id: "direct", name: "Direct to Landlord" },
  ],
  other: [
    { id: "tax",     name: "Tax / Government" },
    { id: "school",  name: "School Fees" },
    { id: "hospital",name: "Hospital Bill" },
  ],
};

type Step = "category" | "provider" | "details";

export default function Bills() {
  const { toast } = useToast();
  const [step, setStep] = useState<Step>("category");
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [selectedProvider, setSelectedProvider] = useState<string | null>(null);
  const [accountNumber, setAccountNumber] = useState("");
  const [amount, setAmount] = useState("");

  const category = CATEGORIES.find((c) => c.id === selectedCategory);
  const providers = selectedCategory ? PROVIDERS[selectedCategory] ?? [] : [];
  const provider = providers.find((p) => p.id === selectedProvider);

  const canPay = accountNumber.length >= 5 && Number(amount) > 0;

  const handleCategorySelect = (id: string) => {
    setSelectedCategory(id);
    setSelectedProvider(null);
    setStep("provider");
  };

  const handleProviderSelect = (id: string) => {
    setSelectedProvider(id);
    setStep("details");
  };

  const handlePay = () => {
    if (!canPay) return;
    toast({
      description: `An biya ${provider?.name ?? "bill"} — ₦${Number(amount).toLocaleString()} (${accountNumber})`,
      duration: 3000,
    });
  };

  const goBack = () => {
    if (step === "details")  { setStep("provider"); return; }
    if (step === "provider") { setStep("category"); return; }
  };

  return (
    <PageTransition className="flex flex-col min-h-screen bg-background pb-8">
      {/* Header */}
      <header className="px-5 pt-8 pb-4 flex items-center gap-4 sticky top-0 bg-background/90 backdrop-blur-md z-10 border-b border-border/40">
        {step === "category" ? (
          <Link href="/" className="w-10 h-10 rounded-full bg-card border border-border flex items-center justify-center shrink-0 active:scale-95 transition-transform">
            <ArrowLeft className="w-5 h-5 text-foreground" />
          </Link>
        ) : (
          <button
            onClick={goBack}
            className="w-10 h-10 rounded-full bg-card border border-border flex items-center justify-center shrink-0 active:scale-95 transition-transform"
          >
            <ArrowLeft className="w-5 h-5 text-foreground" />
          </button>
        )}
        <div>
          <h1 className="text-lg font-bold text-foreground leading-tight">
            {step === "category" && "Lissafi"}
            {step === "provider" && (category?.en ?? "Bills")}
            {step === "details" && `${provider?.name ?? "Bills"}`}
          </h1>
          <p className="text-xs text-muted-foreground font-medium">
            {step === "category" && "Bills"}
            {step === "provider" && (category?.ha ?? "Zaɓi mai bada aiki")}
            {step === "details" && "Shigar da bayani / Enter details"}
          </p>
        </div>

        {/* Breadcrumb dots */}
        <div className="ml-auto flex items-center gap-1.5">
          {(["category", "provider", "details"] as Step[]).map((s) => (
            <div
              key={s}
              className={cn(
                "rounded-full transition-all",
                step === s ? "w-5 h-2 bg-primary" : "w-2 h-2 bg-border"
              )}
            />
          ))}
        </div>
      </header>

      <main className="flex-1 px-5 pt-5">

        {/* ── STEP 1: Category ── */}
        {step === "category" && (
          <div>
            <p className="text-sm text-muted-foreground mb-4">
              Zaɓi irin lissafin da kake son biya / Choose the type of bill to pay
            </p>
            <div className="grid grid-cols-2 gap-3">
              {CATEGORIES.map((cat) => {
                const Icon = cat.icon;
                return (
                  <button
                    key={cat.id}
                    data-testid={`category-${cat.id}`}
                    onClick={() => handleCategorySelect(cat.id)}
                    className={cn(
                      "flex flex-col items-start gap-3 p-4 rounded-2xl border bg-card transition-all active:scale-95 text-left hover:border-primary/40",
                      cat.border
                    )}
                  >
                    <div className={cn("w-11 h-11 rounded-xl flex items-center justify-center", cat.color)}>
                      <Icon className="w-5 h-5" />
                    </div>
                    <div>
                      <p className="font-semibold text-sm text-foreground">{cat.en}</p>
                      <p className="text-xs text-muted-foreground">{cat.ha}</p>
                    </div>
                    <ArrowRight className="w-4 h-4 text-muted-foreground self-end" />
                  </button>
                );
              })}
            </div>
          </div>
        )}

        {/* ── STEP 2: Provider ── */}
        {step === "provider" && category && (
          <div>
            <div className={cn("inline-flex items-center gap-2 px-3 py-1.5 rounded-full text-xs font-semibold mb-5", category.color)}>
              <category.icon className="w-3.5 h-3.5" />
              {category.en} — {category.ha}
            </div>

            <p className="text-sm text-muted-foreground mb-4">
              Zaɓi kamfani / Select provider
            </p>

            <div className="flex flex-col gap-3">
              {providers.map((prov) => (
                <button
                  key={prov.id}
                  data-testid={`provider-${prov.id}`}
                  onClick={() => handleProviderSelect(prov.id)}
                  className="flex items-center justify-between p-4 rounded-2xl border border-border bg-card hover:border-primary/40 active:scale-[0.98] transition-all text-left"
                >
                  <div className="flex items-center gap-3">
                    <div className={cn("w-10 h-10 rounded-full flex items-center justify-center", category.color)}>
                      <category.icon className="w-4 h-4" />
                    </div>
                    <span className="font-semibold text-sm text-foreground">{prov.name}</span>
                  </div>
                  <ArrowRight className="w-4 h-4 text-muted-foreground" />
                </button>
              ))}
            </div>
          </div>
        )}

        {/* ── STEP 3: Details ── */}
        {step === "details" && category && provider && (
          <div className="flex flex-col gap-5">
            {/* Summary chip */}
            <div className={cn("inline-flex items-center gap-2 px-3 py-1.5 rounded-full text-xs font-semibold", category.color)}>
              <category.icon className="w-3.5 h-3.5" />
              {provider.name}
            </div>

            {/* Account / Meter Number */}
            <section>
              <label className="text-sm font-semibold text-foreground block mb-2">
                {selectedCategory === "electricity" ? "Lambar Mita / Meter Number" :
                 selectedCategory === "tv"          ? "Smart Card / IUC Number" :
                 selectedCategory === "internet"    ? "Account / Username" :
                                                     "Lambar Asusun / Account Number"}
              </label>
              <input
                data-testid="input-account-number"
                type="text"
                value={accountNumber}
                onChange={(e) => setAccountNumber(e.target.value)}
                placeholder={
                  selectedCategory === "electricity" ? "e.g. 45210012345" :
                  selectedCategory === "tv"          ? "e.g. 1234567890" :
                  "Enter account number"
                }
                className="w-full h-12 px-4 bg-card border border-border rounded-xl text-sm outline-none focus:border-primary focus:ring-1 focus:ring-primary transition-all placeholder:text-muted-foreground"
              />
            </section>

            {/* Amount */}
            <section>
              <label className="text-sm font-semibold text-foreground block mb-2">
                Adadin Kuɗi / Amount (₦)
              </label>
              <div className="relative">
                <span className="absolute inset-y-0 left-4 flex items-center text-muted-foreground font-semibold">₦</span>
                <input
                  data-testid="input-bill-amount"
                  type="number"
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                  placeholder="0.00"
                  className="w-full h-12 pl-8 pr-4 bg-card border border-border rounded-xl text-sm outline-none focus:border-primary focus:ring-1 focus:ring-primary transition-all placeholder:text-muted-foreground"
                />
              </div>
            </section>

            {/* Summary card */}
            {canPay && (
              <div className="bg-primary/5 border border-primary/20 rounded-2xl p-4 flex flex-col gap-2">
                <p className="text-xs font-semibold text-primary mb-1">Tabbataccen Bayani / Confirm Details</p>
                {[
                  { label: "Kamfani / Provider", value: provider.name },
                  { label: "Asusun / Account",   value: accountNumber },
                  { label: "Adadi / Amount",      value: `₦${Number(amount).toLocaleString()}` },
                ].map((row) => (
                  <div key={row.label} className="flex justify-between">
                    <span className="text-xs text-muted-foreground">{row.label}</span>
                    <span className="text-xs font-semibold text-foreground">{row.value}</span>
                  </div>
                ))}
              </div>
            )}

            {/* Pay button */}
            <button
              data-testid="button-pay"
              onClick={handlePay}
              className={cn(
                "w-full py-4 rounded-2xl font-bold text-lg shadow-sm transition-all active:scale-[0.98] flex items-center justify-center gap-2",
                canPay
                  ? "bg-primary text-primary-foreground"
                  : "bg-muted text-muted-foreground cursor-not-allowed"
              )}
            >
              {canPay && <Check className="w-5 h-5" />}
              Biya Yanzu / Pay Now
            </button>
          </div>
        )}
      </main>
    </PageTransition>
  );
}
