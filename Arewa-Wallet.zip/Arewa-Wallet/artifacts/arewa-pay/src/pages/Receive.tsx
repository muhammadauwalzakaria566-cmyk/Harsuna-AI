import { ArrowLeft, Copy, Share2 } from "lucide-react";
import { Link } from "wouter";
import { PageTransition } from "@/components/PageTransition";
import { useToast } from "@/hooks/use-toast";

export default function Receive() {
  const { toast } = useToast();

  const handleCopy = () => {
    navigator.clipboard.writeText("0812 3456 789");
    toast({
      description: "An kwafe lamba / Account number copied",
      duration: 2000,
    });
  };

  return (
    <PageTransition className="flex flex-col min-h-screen bg-background">
      <header className="px-5 pt-8 pb-4 flex items-center gap-4 sticky top-0 bg-background/80 backdrop-blur-md z-10">
        <Link href="/" className="w-10 h-10 rounded-full bg-card border border-border flex items-center justify-center shrink-0">
          <ArrowLeft className="w-5 h-5 text-foreground" />
        </Link>
        <div>
          <h1 className="text-lg font-bold text-foreground leading-tight">Karɓa Kuɗi</h1>
          <p className="text-xs text-muted-foreground font-medium">Receive Money</p>
        </div>
      </header>

      <main className="flex-1 px-5 flex flex-col items-center py-6">
        <div className="w-full bg-card border border-border rounded-3xl p-8 shadow-sm flex flex-col items-center relative overflow-hidden">
          {/* Decorative background circle */}
          <div className="absolute top-0 right-0 -mr-16 -mt-16 w-48 h-48 rounded-full bg-primary/5 blur-3xl" />
          
          <div className="bg-background border-2 border-dashed border-border rounded-2xl p-6 w-full max-w-[240px] aspect-square flex flex-col items-center justify-center mb-8 relative">
            {/* Fake QR Code using CSS Grid for the visual vibe */}
            <div className="grid grid-cols-5 gap-1.5 w-32 h-32 opacity-80">
              <div className="col-span-2 row-span-2 bg-foreground rounded-sm" />
              <div className="bg-muted rounded-sm" />
              <div className="col-span-2 row-span-2 bg-foreground rounded-sm" />
              
              <div className="bg-primary rounded-sm" />
              <div className="col-span-2 bg-foreground rounded-sm" />
              
              <div className="col-span-2 bg-muted rounded-sm" />
              <div className="bg-accent rounded-sm" />
              <div className="col-span-2 bg-foreground rounded-sm" />
              
              <div className="col-span-2 row-span-2 bg-foreground rounded-sm" />
              <div className="bg-foreground rounded-sm" />
              <div className="col-span-2 row-span-2 bg-foreground rounded-sm" />
              
              <div className="bg-primary rounded-sm" />
            </div>
            
            <p className="text-xs text-muted-foreground font-medium absolute bottom-4">
              Scan to pay me
            </p>
          </div>

          <div className="text-center w-full">
            <h2 className="text-2xl font-bold text-foreground mb-1">Ibrahim Bello</h2>
            <p className="text-sm font-medium text-muted-foreground mb-6">Arewa Pay</p>
            
            <div className="bg-background border border-border rounded-xl p-4 flex items-center justify-between group">
              <div className="text-left">
                <p className="text-xs text-muted-foreground font-medium mb-1">Account Number</p>
                <p className="font-mono text-lg font-bold tracking-wider text-foreground">
                  0812 3456 789
                </p>
              </div>
              <button 
                onClick={handleCopy}
                className="w-10 h-10 rounded-full bg-card border border-border flex items-center justify-center text-muted-foreground hover:text-foreground hover:bg-muted transition-colors active:scale-95"
              >
                <Copy className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>

        <button className="w-full mt-6 py-4 rounded-2xl bg-primary text-primary-foreground font-bold text-lg shadow-sm transition-transform active:scale-[0.98] flex items-center justify-center gap-2">
          <Share2 className="w-5 h-5" />
          Raba Bayani / Share Details
        </button>
      </main>
    </PageTransition>
  );
}
