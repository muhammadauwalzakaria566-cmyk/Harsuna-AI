import { ArrowDown, ArrowUp, Eye, EyeOff } from "lucide-react";
import { useState } from "react";
import { Link } from "wouter";

interface BalanceCardProps {
  balance?: string;
  accountNumber?: string;
}

export function BalanceCard({ balance = "0.00", accountNumber }: BalanceCardProps) {
  const [showBalance, setShowBalance] = useState(true);

  const formattedBalance = (() => {
    const n = parseFloat(balance);
    return isNaN(n)
      ? "0.00"
      : n.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  })();

  return (
    <div className="rounded-3xl p-6 text-white shadow-sm overflow-hidden relative isolate">
      {/* Indigo gradient background */}
      <div 
        className="absolute inset-0 -z-10"
        style={{
          background: 'linear-gradient(135deg, #1e2b4f 0%, #2B3A67 100%)'
        }}
      />
      
      {/* Decorative circles */}
      <div className="absolute top-0 right-0 -mr-8 -mt-8 w-32 h-32 rounded-full bg-white/10 blur-2xl -z-10" />
      <div className="absolute bottom-0 left-0 -ml-8 -mb-8 w-24 h-24 rounded-full bg-black/10 blur-xl -z-10" />

      <div className="flex justify-between items-start mb-4">
        <div>
          <p className="text-white/80 text-sm font-medium">Jimillar Kuɗi / Total Balance</p>
          <div className="flex items-center gap-3 mt-1">
            <h2 className="text-3xl font-bold tracking-tight">
              {showBalance ? `₦ ${formattedBalance}` : "••••••••"}
            </h2>
            <button 
              onClick={() => setShowBalance(!showBalance)}
              className="p-1 rounded-full hover:bg-white/20 transition-colors opacity-80 hover:opacity-100"
              aria-label="Toggle balance visibility"
            >
              {showBalance ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
            </button>
          </div>
          <p className="text-white/70 text-xs mt-1">
            {accountNumber ? `Lamba: ${accountNumber}` : "Arewa Pay Wallet"}
          </p>
        </div>
        
        {/* Subtle texture/icon top right could go here */}
      </div>

      <div className="flex gap-3 mt-6">
        <Link 
          href="/send"
          className="flex-1 bg-white text-primary rounded-full py-2.5 px-4 flex items-center justify-center gap-2 font-semibold text-sm transition-transform active:scale-95 shadow-sm"
        >
          <ArrowUp className="w-4 h-4" />
          Aika Kuɗi
        </Link>
        <Link 
          href="/receive"
          className="flex-1 bg-primary-foreground/20 text-white rounded-full py-2.5 px-4 flex items-center justify-center gap-2 font-semibold text-sm backdrop-blur-sm transition-transform active:scale-95 border border-white/20"
        >
          <ArrowDown className="w-4 h-4" />
          Karɓa
        </Link>
      </div>
    </div>
  );
}
