import { Link, useLocation } from "wouter";
import { Home, Send, ArrowDownToLine, History, User } from "lucide-react";
import { cn } from "@/lib/utils";

export function BottomNav() {
  const [location] = useLocation();

  const navItems = [
    { icon: Home,            label: "Gida",    sub: "Home",    href: "/" },
    { icon: Send,            label: "Aika",    sub: "Send",    href: "/send" },
    { icon: ArrowDownToLine, label: "Karɓa",   sub: "Receive", href: "/receive", primary: true },
    { icon: History,         label: "Tarihi",  sub: "History", href: "/history" },
    { icon: User,            label: "Asusun",  sub: "Profile", href: "/profile" },
  ];

  return (
    /* Sits at the bottom of the flex column — no fixed positioning needed */
    <div className="relative z-20 flex-shrink-0 bg-card border-t border-border/50 px-4 pt-2 pb-3 rounded-t-3xl shadow-[0_-4px_24px_rgba(0,0,0,0.06)]">
      <div className="flex justify-between items-end">
        {navItems.map((item) => {
          const isActive = location === item.href;
          const Icon = item.icon;

          if (item.primary) {
            return (
              <Link
                key={item.href}
                href={item.href}
                data-testid={`nav-${item.href.replace("/", "") || "home"}`}
                className="flex flex-col items-center justify-center -mt-7 outline-none"
              >
                <div
                  className={cn(
                    "h-14 w-14 rounded-full flex items-center justify-center shadow-md ring-4 ring-background transition-transform active:scale-95",
                    isActive
                      ? "bg-primary shadow-primary/30"
                      : "bg-primary/90 shadow-primary/20"
                  )}
                >
                  <Icon className="h-6 w-6 text-primary-foreground" />
                </div>
                <span className={cn("text-[10px] font-semibold mt-1.5", isActive ? "text-primary" : "text-muted-foreground")}>
                  {item.label}
                </span>
              </Link>
            );
          }

          return (
            <Link
              key={item.href}
              href={item.href}
              data-testid={`nav-${item.href.replace("/", "") || "home"}`}
              className={cn(
                "flex flex-col items-center justify-center w-14 pt-1 outline-none transition-colors",
                isActive ? "text-primary" : "text-muted-foreground hover:text-foreground"
              )}
            >
              <Icon className={cn("h-5 w-5 mb-1", isActive && "stroke-[2.5px]")} />
              <span className="text-[10px] font-semibold">{item.label}</span>
              <span className="text-[9px] font-normal opacity-70">{item.sub}</span>
            </Link>
          );
        })}
      </div>
    </div>
  );
}
