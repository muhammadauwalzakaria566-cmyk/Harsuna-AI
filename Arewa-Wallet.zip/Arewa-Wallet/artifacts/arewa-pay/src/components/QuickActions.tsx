import { ArrowDownToLine, ArrowUpFromLine, Phone, Receipt } from "lucide-react";
import { Link } from "wouter";

const actions = [
  {
    icon: ArrowUpFromLine,
    en: "Send",
    ha: "Aika",
    href: "/send",
    color: "bg-[#E4E8F2] text-[#2B3A67]",
  },
  {
    icon: ArrowDownToLine,
    en: "Receive",
    ha: "Karɓa",
    href: "/receive",
    color: "bg-[#F3E4D9] text-[#C97B4A]",
  },
  {
    icon: Phone,
    en: "Airtime & Data",
    ha: "Katin Waya",
    href: "/airtime",
    color: "bg-[#E4E8F2] text-[#2B3A67]",
  },
  {
    icon: Receipt,
    en: "Bills",
    ha: "Lissafi",
    href: "/bills",
    color: "bg-[#F3E4D9] text-[#C97B4A]",
  },
];

export function QuickActions() {
  return (
    <div className="grid grid-cols-4 gap-3">
      {actions.map((action, i) => (
        <Link
          key={i}
          href={action.href}
          data-testid={`quick-action-${action.en.toLowerCase().replace(/\s+/g, "-")}`}
          className="flex flex-col items-center group outline-none"
        >
          <div className="w-[4.25rem] h-[4.25rem] bg-card border border-border shadow-sm rounded-2xl flex items-center justify-center mb-2 transition-transform active:scale-95 group-hover:border-primary/30">
            <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${action.color}`}>
              <action.icon className="w-5 h-5" />
            </div>
          </div>
          <span className="text-xs font-semibold text-foreground text-center leading-tight">{action.en}</span>
          <span className="text-[10px] text-muted-foreground">{action.ha}</span>
        </Link>
      ))}
    </div>
  );
}
