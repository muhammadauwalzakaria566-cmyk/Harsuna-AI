import { ArrowDownLeft, ArrowUpRight, Phone, Receipt, User, ChevronRight } from "lucide-react";
import { Link } from "wouter";
import { cn } from "@/lib/utils";

export type Transaction = {
  id: string;
  type: "send" | "receive" | "airtime" | "bill" | "deposit";
  name: string;
  detail: string;
  amount: number;
  timeAgo: string;
  dateStr?: string;
  // Receipt fields
  timestamp: string;    // "Jul 7, 2026 · 9:42 AM"
  reference: string;    // "APY-20260707-0001"
  status: "completed" | "pending" | "failed";
  account?: string;     // phone or account number for airtime/bills
};

export const MOCK_TRANSACTIONS: Transaction[] = [
  {
    id: "t1",
    type: "send",
    name: "Aisha Musa",
    detail: "Aika Kuɗi",
    amount: -5000,
    timeAgo: "2 hours ago",
    dateStr: "Yau / Today",
    timestamp: "Yuli 7, 2026 · 9:42 AM",
    reference: "APY-20260707-0001",
    status: "completed",
  },
  {
    id: "t2",
    type: "airtime",
    name: "MTN Nigeria",
    detail: "Airtime",
    amount: -1000,
    timeAgo: "5 hours ago",
    dateStr: "Yau / Today",
    timestamp: "Yuli 7, 2026 · 6:15 AM",
    reference: "APY-20260707-0002",
    status: "completed",
    account: "0801 234 5678",
  },
  {
    id: "t3",
    type: "receive",
    name: "Musa Sule",
    detail: "An Aiko Maka",
    amount: 15000,
    timeAgo: "Yesterday",
    dateStr: "Jiya / Yesterday",
    timestamp: "Yuli 6, 2026 · 4:30 PM",
    reference: "APY-20260706-0015",
    status: "completed",
  },
  {
    id: "t4",
    type: "bill",
    name: "NEPA / AEDC",
    detail: "Wutar Lantarki",
    amount: -8500,
    timeAgo: "Yesterday",
    dateStr: "Jiya / Yesterday",
    timestamp: "Yuli 6, 2026 · 11:05 AM",
    reference: "APY-20260706-0008",
    status: "completed",
    account: "45129000872",
  },
  {
    id: "t5",
    type: "deposit",
    name: "PiggyVest",
    detail: "Ajiya Returned",
    amount: 25000,
    timeAgo: "2 days ago",
    dateStr: "Kwanakin Baya",
    timestamp: "Yuli 5, 2026 · 8:00 AM",
    reference: "APY-20260705-0003",
    status: "completed",
  },
  {
    id: "t6",
    type: "send",
    name: "Ibrahim K.",
    detail: "Aika Kuɗi",
    amount: -12000,
    timeAgo: "Jun 24",
    dateStr: "Kwanakin Baya",
    timestamp: "Yun 24, 2026 · 2:18 PM",
    reference: "APY-20260624-0011",
    status: "completed",
  },
  {
    id: "t7",
    type: "receive",
    name: "Aminu Kano",
    detail: "An Aiko Maka",
    amount: 50000,
    timeAgo: "Jun 22",
    dateStr: "Kwanakin Baya",
    timestamp: "Yun 22, 2026 · 10:47 AM",
    reference: "APY-20260622-0007",
    status: "completed",
  },
];

const iconMap: Record<
  Transaction["type"],
  { icon: React.ElementType; color: string }
> = {
  send:    { icon: User,          color: "bg-[#E4E8F2] text-[#2B3A67]" },
  receive: { icon: ArrowDownLeft, color: "bg-[#E4E8F2] text-[#2B3A67]" },
  airtime: { icon: Phone,         color: "bg-[#E4E8F2] text-[#2B3A67]" },
  bill:    { icon: Receipt,       color: "bg-[#F3E4D9] text-[#C97B4A]" },
  deposit: { icon: ArrowDownLeft, color: "bg-[#F3E4D9] text-[#C97B4A]" },
};

export function TransactionItem({ transaction }: { transaction: Transaction }) {
  const isNegative = transaction.amount < 0;
  const config = iconMap[transaction.type];
  const Icon = config.icon;

  return (
    <Link
      href={`/transaction/${transaction.id}`}
      className="flex items-center justify-between py-3 group outline-none focus-visible:ring-2 focus-visible:ring-primary focus-visible:ring-offset-1 active:bg-muted/40 -mx-1 px-1 rounded-xl transition-colors"
    >
      <div className="flex items-center gap-3 min-w-0">
        <div
          className={cn(
            "w-11 h-11 rounded-full flex items-center justify-center shrink-0",
            config.color
          )}
        >
          <Icon className="w-5 h-5" />
        </div>
        <div className="min-w-0">
          <p className="font-semibold text-sm text-foreground truncate">
            {transaction.name}
          </p>
          <div className="flex items-center gap-1.5 mt-0.5">
            <span className="text-xs text-muted-foreground">{transaction.detail}</span>
            <span className="w-1 h-1 rounded-full bg-border" />
            <span className="text-xs text-muted-foreground">{transaction.timeAgo}</span>
          </div>
        </div>
      </div>

      <div className="flex items-center gap-1.5 shrink-0 ml-2">
        <span
          className={cn(
            "font-bold text-sm",
            isNegative ? "text-destructive" : "text-primary"
          )}
        >
          {isNegative ? "-" : "+"}₦
          {Math.abs(transaction.amount).toLocaleString(undefined, {
            minimumFractionDigits: 2,
            maximumFractionDigits: 2,
          })}
        </span>
        <ChevronRight className="w-4 h-4 text-muted-foreground/50 group-hover:text-muted-foreground transition-colors" />
      </div>
    </Link>
  );
}
