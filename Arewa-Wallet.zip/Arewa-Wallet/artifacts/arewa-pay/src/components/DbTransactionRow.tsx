import { ArrowDownLeft, ArrowUpRight, Phone, Receipt, ChevronRight, TrendingDown } from "lucide-react";
import { Link } from "wouter";
import { cn } from "@/lib/utils";
import type { ApiTransaction } from "@/lib/api";

const ICON_MAP: Record<
  ApiTransaction["type"],
  { icon: React.ElementType; color: string }
> = {
  send:    { icon: ArrowUpRight,  color: "bg-[#E4E8F2] text-[#2B3A67]" },
  receive: { icon: ArrowDownLeft, color: "bg-[#E4E8F2] text-[#2B3A67]" },
  airtime: { icon: Phone,         color: "bg-blue-100 text-blue-700"    },
  bill:    { icon: Receipt,       color: "bg-[#F3E4D9] text-[#C97B4A]" },
  deposit: { icon: TrendingDown,  color: "bg-[#F3E4D9] text-[#C97B4A]" },
};

const TYPE_LABEL: Record<ApiTransaction["type"], { ha: string }> = {
  send:    { ha: "Aika Kuɗi" },
  receive: { ha: "An Aiko Maka" },
  airtime: { ha: "Katin Waya" },
  bill:    { ha: "Biyan Lissafi" },
  deposit: { ha: "Ajiya" },
};

function formatRelativeTime(isoStr: string): string {
  const date = new Date(isoStr);
  const now = new Date();
  const diffMs = now.getTime() - date.getTime();
  const diffMins = Math.floor(diffMs / 60_000);
  if (diffMins < 1) return "Yanzu / Just now";
  if (diffMins < 60) return `${diffMins}m ago`;
  const diffHrs = Math.floor(diffMins / 60);
  if (diffHrs < 24) return `${diffHrs}h ago`;
  const diffDays = Math.floor(diffHrs / 24);
  if (diffDays === 1) return "Jiya / Yesterday";
  if (diffDays < 7) return `${diffDays} days ago`;
  return date.toLocaleDateString("en-NG", { month: "short", day: "numeric" });
}

export function DbTransactionRow({ txn }: { txn: ApiTransaction }) {
  const amount = parseFloat(txn.amount);
  const isCredit = amount > 0;
  const config = ICON_MAP[txn.type];
  const Icon = config.icon;

  return (
    <Link
      href={`/transaction/db/${txn.id}`}
      className="flex items-center justify-between py-3 group outline-none focus-visible:ring-2 focus-visible:ring-primary focus-visible:ring-offset-1 active:bg-muted/40 -mx-1 px-1 rounded-xl transition-colors"
    >
      <div className="flex items-center gap-3 min-w-0">
        <div
          className={cn(
            "w-11 h-11 rounded-full flex items-center justify-center shrink-0",
            config.color,
          )}
        >
          <Icon className="w-5 h-5" />
        </div>
        <div className="min-w-0">
          <p className="font-semibold text-sm text-foreground truncate">
            {txn.counterparty}
          </p>
          <div className="flex items-center gap-1.5 mt-0.5">
            <span className="text-xs text-muted-foreground">
              {TYPE_LABEL[txn.type].ha}
            </span>
            <span className="w-1 h-1 rounded-full bg-border" />
            <span className="text-xs text-muted-foreground">
              {formatRelativeTime(txn.createdAt)}
            </span>
          </div>
        </div>
      </div>

      <div className="flex items-center gap-1.5 shrink-0 ml-2">
        <span
          className={cn(
            "font-bold text-sm tabular-nums",
            isCredit ? "text-primary" : "text-destructive",
          )}
        >
          {isCredit ? "+" : "-"}₦
          {Math.abs(amount).toLocaleString(undefined, {
            minimumFractionDigits: 2,
            maximumFractionDigits: 2,
          })}
        </span>
        <ChevronRight className="w-4 h-4 text-muted-foreground/50 group-hover:text-muted-foreground transition-colors" />
      </div>
    </Link>
  );
}

export type { ApiTransaction };
