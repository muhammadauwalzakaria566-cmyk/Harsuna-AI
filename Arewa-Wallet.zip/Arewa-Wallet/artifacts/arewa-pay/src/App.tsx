import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import NotFound from '@/pages/not-found';
import { Route, Switch, Router as WouterRouter, useLocation, Redirect } from 'wouter';
import { BottomNav } from '@/components/BottomNav';
import { AuthProvider, useAuth } from '@/context/AuthContext';

// Pages
import Home from '@/pages/Home';
import Send from '@/pages/Send';
import Receive from '@/pages/Receive';
import History from '@/pages/History';
import Profile from '@/pages/Profile';
import Airtime from '@/pages/Airtime';
import Bills from '@/pages/Bills';
import Notifications from '@/pages/Notifications';
import TransactionReceipt from '@/pages/TransactionReceipt';
import TransactionReceiptDb from '@/pages/TransactionReceiptDb';
import Login from '@/pages/Login';
import Signup from '@/pages/Signup';

const queryClient = new QueryClient();

const AUTH_ROUTES = ['/login', '/signup'];

function AppShell() {
  const [location] = useLocation();
  const { isAuthenticated, isLoading } = useAuth();
  const isAuthRoute = AUTH_ROUTES.includes(location);

  // Show nothing while we check session (avoids flash)
  if (isLoading) {
    return (
      <div className="h-[100dvh] w-full flex items-center justify-center bg-background">
        <div className="w-8 h-8 rounded-full border-4 border-primary border-t-transparent animate-spin" />
      </div>
    );
  }

  // Auth routes — no phone frame, no bottom nav
  if (isAuthRoute) {
    return (
      <div className="h-[100dvh] w-full bg-muted/30 font-sans flex justify-center overflow-hidden">
        <div className="w-full max-w-[430px] bg-background shadow-2xl h-[100dvh] md:border-x md:border-border/50">
          <Switch>
            <Route path="/login" component={Login} />
            <Route path="/signup" component={Signup} />
          </Switch>
        </div>
      </div>
    );
  }

  // Protected routes — redirect to /login when not authenticated
  if (!isAuthenticated) {
    return <Redirect to="/login" />;
  }

  return (
    <div className="h-[100dvh] w-full bg-muted/30 font-sans flex justify-center overflow-hidden">
      <div className="w-full max-w-[430px] bg-background shadow-2xl flex flex-col h-[100dvh] md:border-x md:border-border/50">
        <div className="flex-1 overflow-y-auto overflow-x-hidden">
          <Switch>
            <Route path="/" component={Home} />
            <Route path="/send" component={Send} />
            <Route path="/receive" component={Receive} />
            <Route path="/history" component={History} />
            <Route path="/profile" component={Profile} />
            <Route path="/airtime" component={Airtime} />
            <Route path="/bills" component={Bills} />
            <Route path="/notifications" component={Notifications} />
            <Route path="/transaction/:id" component={TransactionReceipt} />
            <Route path="/transaction/db/:id" component={TransactionReceiptDb} />
            <Route component={NotFound} />
          </Switch>
        </div>
        <BottomNav />
      </div>
    </div>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, '')}>
          <AuthProvider>
            <AppShell />
          </AuthProvider>
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
