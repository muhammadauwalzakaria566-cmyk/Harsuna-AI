import { Router, type Request, type Response } from "express";
import bcrypt from "bcryptjs";
import { db } from "@workspace/db";
import { usersTable } from "@workspace/db";
import { eq } from "drizzle-orm";

const router = Router();

/**
 * Normalize a Nigerian phone number to canonical 080XXXXXXXX form.
 * Accepts: 080XXXXXXXX, +23480XXXXXXXX, 23480XXXXXXXX (with or without spaces).
 * Returns null if the input is not a valid Nigerian mobile number.
 */
function normalizePhone(raw: string): string | null {
  const digits = raw.replace(/[\s\-().+]/g, "");
  // +234XXXXXXXXXX → 0XXXXXXXXXX
  if (/^234\d{10}$/.test(digits)) return "0" + digits.slice(3);
  // Already 0XXXXXXXXXX
  if (/^0\d{10}$/.test(digits)) return digits;
  return null;
}

/** Generate a unique 10-digit account number starting with "03" */
async function generateAccountNumber(): Promise<string> {
  for (let i = 0; i < 20; i++) {
    const num =
      "03" +
      Math.floor(Math.random() * 100_000_000)
        .toString()
        .padStart(8, "0");
    const rows = await db
      .select({ id: usersTable.id })
      .from(usersTable)
      .where(eq(usersTable.accountNumber, num));
    if (rows.length === 0) return num;
  }
  throw new Error("Failed to generate unique account number");
}

function safeUser(user: typeof usersTable.$inferSelect) {
  return {
    id: user.id,
    phone: user.phone,
    fullName: user.fullName,
    accountNumber: user.accountNumber,
    balance: user.balance,
  };
}

// POST /api/auth/signup
router.post("/auth/signup", async (req: Request, res: Response) => {
  const { phone, fullName, pin } = req.body as {
    phone?: string;
    fullName?: string;
    pin?: string;
  };

  if (!phone || !fullName || !pin) {
    res
      .status(400)
      .json({ error: "Lambar waya, suna, da PIN ana bukata / Phone, name and PIN are required" });
    return;
  }

  // Canonical form: strip all spaces, ensure 0XXXXXXXXXX format
  const canonicalPhone = normalizePhone(phone.trim());
  const trimmedName = fullName.trim();

  if (!/^\d{4}$/.test(pin)) {
    res
      .status(400)
      .json({ error: "PIN dole ya zama lamba 4 / PIN must be exactly 4 digits" });
    return;
  }

  if (!canonicalPhone) {
    res.status(400).json({ error: "Lambar waya ba daidai ba / Invalid phone number" });
    return;
  }

  const existing = await db
    .select({ id: usersTable.id })
    .from(usersTable)
    .where(eq(usersTable.phone, canonicalPhone));

  if (existing.length > 0) {
    res
      .status(409)
      .json({ error: "Lambar waya an riga an yi amfani da ita / Phone already registered" });
    return;
  }

  const pinHash = await bcrypt.hash(pin, 12);
  const accountNumber = await generateAccountNumber();

  const [user] = await db
    .insert(usersTable)
    .values({
      phone: canonicalPhone,
      fullName: trimmedName,
      pinHash,
      accountNumber,
      balance: "0.00",
    })
    .returning();

  req.session.userId = user.id;

  res.status(201).json(safeUser(user));
});

// POST /api/auth/login
router.post("/auth/login", async (req: Request, res: Response) => {
  const { phone, pin } = req.body as { phone?: string; pin?: string };

  if (!phone || !pin) {
    res.status(400).json({ error: "Lambar waya da PIN ana bukata / Phone and PIN required" });
    return;
  }

  const canonicalPhone = normalizePhone(phone.trim());
  if (!canonicalPhone) {
    res.status(401).json({ error: "Lambar waya ko PIN ba daidai ba / Incorrect phone or PIN" });
    return;
  }

  const [user] = await db
    .select()
    .from(usersTable)
    .where(eq(usersTable.phone, canonicalPhone));

  if (!user) {
    res.status(401).json({ error: "Lambar waya ko PIN ba daidai ba / Incorrect phone or PIN" });
    return;
  }

  const valid = await bcrypt.compare(pin, user.pinHash);
  if (!valid) {
    res.status(401).json({ error: "Lambar waya ko PIN ba daidai ba / Incorrect phone or PIN" });
    return;
  }

  req.session.userId = user.id;

  res.json(safeUser(user));
});

// GET /api/auth/me
router.get("/auth/me", async (req: Request, res: Response) => {
  if (!req.session.userId) {
    res.status(401).json({ error: "Ba a shiga ba / Not authenticated" });
    return;
  }

  const [user] = await db
    .select()
    .from(usersTable)
    .where(eq(usersTable.id, req.session.userId));

  if (!user) {
    req.session.destroy(() => {});
    res.status(401).json({ error: "Ba a sami mai amfani ba / User not found" });
    return;
  }

  res.json(safeUser(user));
});

// POST /api/auth/logout
router.post("/auth/logout", (req: Request, res: Response) => {
  req.session.destroy((err) => {
    if (err) {
      req.log?.error({ err }, "Session destroy error");
      res.status(500).json({ error: "Fita bai yi ba / Logout failed" });
      return;
    }
    res.clearCookie("arewa_sid");
    res.json({ success: true });
  });
});

export default router;
