import { Router, type Request, type Response, type NextFunction } from "express";
import { db } from "@workspace/db";
import { transactionsTable } from "@workspace/db";
import { eq, desc, and } from "drizzle-orm";

const router = Router();

// GET /api/transactions — list the authenticated user's transactions
router.get("/transactions", async (req: Request, res: Response) => {
  if (!req.session.userId) {
    res.status(401).json({ error: "Ba a shiga ba / Not authenticated" });
    return;
  }

  const rows = await db
    .select()
    .from(transactionsTable)
    .where(eq(transactionsTable.userId, req.session.userId))
    .orderBy(desc(transactionsTable.createdAt))
    .limit(100);

  res.json(rows);
});

// GET /api/transactions/:id — single transaction detail
router.get("/transactions/:id", async (req: Request<{ id: string }>, res: Response, _next: NextFunction) => {
  if (!req.session.userId) {
    res.status(401).json({ error: "Ba a shiga ba / Not authenticated" });
    return;
  }

  const txId = parseInt(req.params.id, 10);
  if (isNaN(txId)) {
    res.status(400).json({ error: "ID ba daidai ba / Invalid ID" });
    return;
  }

  const [txn] = await db
    .select()
    .from(transactionsTable)
    .where(
      and(
        eq(transactionsTable.id, txId),
        eq(transactionsTable.userId, req.session.userId),
      ),
    );

  if (!txn) {
    res.status(404).json({ error: "Ba a sami ciniki ba / Transaction not found" });
    return;
  }

  res.json(txn);
});

export default router;
